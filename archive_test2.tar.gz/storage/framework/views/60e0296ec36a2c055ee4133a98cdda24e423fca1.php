

<?php $__env->startSection('title', 'Mes messages'); ?>

<?php $__env->startSection('page-title', 'Mes messages'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="bg-white rounded-lg shadow-sm">
        <?php if($conversations && $conversations->count() > 0): ?>
            <div class="divide-y divide-gray-200">
                <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $otherUser = $conversation->sender_id == Auth::id() 
                            ? \App\Models\User::find($conversation->recipient_id)
                            : \App\Models\User::find($conversation->sender_id);
                        $isUnread = !$conversation->is_read && $conversation->recipient_id == Auth::id();
                    ?>
                    
                    <a href="<?php echo e(route('customer.messages.show', $conversation->trip->slug ?? 'default')); ?>"
                       class="block p-4 hover:bg-gray-50 transition-colors <?php echo e($isUnread ? 'bg-blue-50' : ''); ?>">
                        <div class="flex items-start space-x-3">
                            <div class="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                                <span class="text-sm font-bold text-primary">
                                    <?php echo e(substr($otherUser->name ?? 'U', 0, 2)); ?>

                                </span>
                            </div>
                            <div class="flex-1">
                                <div class="flex items-center justify-between">
                                    <p class="font-medium <?php echo e($isUnread ? 'font-bold text-black' : 'text-text-primary'); ?>">
                                        <?php echo e($otherUser->name ?? 'Utilisateur'); ?>

                                    </p>
                                    <p class="text-xs text-text-secondary">
                                        <?php echo e($conversation->created_at->diffForHumans()); ?>

                                    </p>
                                </div>
                                <?php if($conversation->trip): ?>
                                    <p class="text-sm text-primary mt-1">
                                        <?php echo e($conversation->trip->title); ?>

                                    </p>
                                <?php endif; ?>
                                <p class="text-sm text-text-secondary mt-1 line-clamp-1">
                                    <?php echo e($conversation->content); ?>

                                </p>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="p-8 text-center">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-text-primary">Aucun message</h3>
                <p class="mt-1 text-sm text-text-secondary">Commencez à explorer les offres pour contacter les organisateurs.</p>
                <a href="<?php echo e(route('home')); ?>" class="mt-4 inline-block px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark">
                    Explorer les offres
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/customer/messages/index.blade.php ENDPATH**/ ?>