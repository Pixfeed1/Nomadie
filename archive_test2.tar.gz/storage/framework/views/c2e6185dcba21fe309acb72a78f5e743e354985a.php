

<?php $__env->startSection('title', 'Nos organisateurs partenaires - Nomadie'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-bg-main min-h-screen">
    <!-- Hero Section -->
    <div class="relative bg-gradient-to-r from-primary to-primary-dark text-white">
        <div class="absolute inset-0 overflow-hidden">
            <div class="absolute inset-0 bg-black opacity-40"></div>
            <img src="<?php echo e(asset('images/vendors-hero.jpg')); ?>" alt="Organisateurs" class="w-full h-full object-cover">
        </div>
        <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
            <div class="max-w-3xl space-y-6">
                <h1 class="text-4xl md:text-5xl font-bold text-white">Trouvez l'organisateur idéal pour votre voyage</h1>
                <p class="text-xl text-white/90">Découvrez <?php echo e($vendors->total()); ?> professionnels qui créent des expériences uniques partout dans le monde.</p>
                <div class="pt-4 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                    <a href="#organisateurs" class="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-accent hover:bg-accent-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent transition-colors">
                        Explorer les organisateurs
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                        </svg>
                    </a>
                    <a href="<?php echo e(route('vendor.register')); ?>" class="inline-flex items-center justify-center px-6 py-3 border border-white text-base font-medium rounded-md shadow-sm text-white bg-transparent hover:bg-white hover:text-primary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white transition-colors">
                        Devenir organisateur
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Search Section -->
    <div class="bg-white shadow-md relative z-10 -mt-8 mb-12 rounded-lg max-w-6xl mx-auto">
        <div class="p-6">
            <form action="<?php echo e(route('vendors.index')); ?>" method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label for="type" class="block text-sm font-medium text-text-secondary mb-1">Type d'offre</label>
                    <select id="type" name="type" class="block w-full rounded-md border-border shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2.5">
                        <option value="">Tous les types</option>
                        <option value="organized_trip" <?php echo e(request('type') == 'organized_trip' ? 'selected' : ''); ?>>Séjours organisés</option>
                        <option value="accommodation" <?php echo e(request('type') == 'accommodation' ? 'selected' : ''); ?>>Hébergements</option>
                        <option value="activity" <?php echo e(request('type') == 'activity' ? 'selected' : ''); ?>>Activités</option>
                        <option value="custom" <?php echo e(request('type') == 'custom' ? 'selected' : ''); ?>>Sur mesure</option>
                    </select>
                </div>
                <div>
                    <label for="destination" class="block text-sm font-medium text-text-secondary mb-1">Destination</label>
                    <select id="destination" name="destination" class="block w-full rounded-md border-border shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2.5">
                        <option value="">Toutes les destinations</option>
                        <?php $__currentLoopData = $countries ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($country->slug); ?>" <?php echo e(request('destination') == $country->slug ? 'selected' : ''); ?>>
                                <?php echo e($country->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label for="rating" class="block text-sm font-medium text-text-secondary mb-1">Note minimale</label>
                    <select id="rating" name="rating" class="block w-full rounded-md border-border shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2.5">
                        <option value="">Toutes les notes</option>
                        <option value="4.5" <?php echo e(request('rating') == '4.5' ? 'selected' : ''); ?>>4.5+ Excellent</option>
                        <option value="4" <?php echo e(request('rating') == '4' ? 'selected' : ''); ?>>4+ Très bien</option>
                        <option value="3.5" <?php echo e(request('rating') == '3.5' ? 'selected' : ''); ?>>3.5+ Bien</option>
                    </select>
                </div>
                <div class="flex items-end">
                    <button type="submit" class="w-full bg-primary hover:bg-primary-dark text-white font-medium py-2.5 px-4 rounded-md transition-colors">
                        <div class="flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                            Rechercher
                        </div>
                    </button>
                </div>
            </form>
            <div class="mt-3 text-right">
                <a href="<?php echo e(route('search.advanced')); ?>" class="text-sm text-primary hover:text-primary-dark font-medium flex items-center justify-end">
                    Recherche avancée
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Contenu principal -->
    <div id="organisateurs" class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
            
            <!-- Sidebar filtres -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-lg shadow-sm overflow-hidden sticky top-6">
                    <div class="p-6 border-b border-border">
                        <h3 class="text-lg font-semibold text-text-primary">Filtres avancés</h3>
                    </div>
                    <div class="p-6 space-y-6">
                        <!-- Types d'offres -->
                        <div>
                            <h4 class="text-sm font-medium text-text-secondary uppercase mb-3">Types d'offres proposées</h4>
                            <div class="space-y-2">
                                <label class="flex items-center">
                                    <input type="checkbox" name="offer_type[]" value="organized_trip"
                                           <?php echo e(in_array('organized_trip', (array)request('offer_type')) ? 'checked' : ''); ?>

                                           class="h-4 w-4 text-primary rounded border-gray-300 focus:ring-primary">
                                    <span class="ml-3 text-sm text-text-primary">Séjours organisés</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="checkbox" name="offer_type[]" value="accommodation"
                                           <?php echo e(in_array('accommodation', (array)request('offer_type')) ? 'checked' : ''); ?>

                                           class="h-4 w-4 text-primary rounded border-gray-300 focus:ring-primary">
                                    <span class="ml-3 text-sm text-text-primary">Hébergements</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="checkbox" name="offer_type[]" value="activity"
                                           <?php echo e(in_array('activity', (array)request('offer_type')) ? 'checked' : ''); ?>

                                           class="h-4 w-4 text-primary rounded border-gray-300 focus:ring-primary">
                                    <span class="ml-3 text-sm text-text-primary">Activités & Expériences</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="checkbox" name="offer_type[]" value="custom"
                                           <?php echo e(in_array('custom', (array)request('offer_type')) ? 'checked' : ''); ?>

                                           class="h-4 w-4 text-primary rounded border-gray-300 focus:ring-primary">
                                    <span class="ml-3 text-sm text-text-primary">Sur mesure</span>
                                </label>
                            </div>
                        </div>

                        <!-- Budget moyen -->
                        <div>
                            <h4 class="text-sm font-medium text-text-secondary uppercase mb-3">Budget moyen par personne</h4>
                            <div class="px-3">
                                <input type="range" id="price-range" name="price_range" min="0" max="5000" step="100" 
                                       value="<?php echo e(request('price_range', 2500)); ?>"
                                       class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-primary">
                                <div class="flex justify-between text-xs text-text-secondary mt-2">
                                    <span>0€</span>
                                    <span id="price-value" class="font-medium text-primary"><?php echo e(request('price_range', 2500)); ?>€</span>
                                    <span>5000€+</span>
                                </div>
                            </div>
                        </div>

                        <!-- Évaluation clients -->
                        <div>
                            <h4 class="text-sm font-medium text-text-secondary uppercase mb-3">Évaluation clients</h4>
                            <div class="space-y-2">
                                <label class="flex items-center">
                                    <input type="checkbox" name="with_reviews" value="1"
                                           <?php echo e(request('with_reviews') ? 'checked' : ''); ?>

                                           class="h-4 w-4 text-primary rounded border-gray-300 focus:ring-primary">
                                    <span class="ml-3 text-sm text-text-primary">Avec avis uniquement</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="checkbox" name="fast_response" value="1"
                                           <?php echo e(request('fast_response') ? 'checked' : ''); ?>

                                           class="h-4 w-4 text-primary rounded border-gray-300 focus:ring-primary">
                                    <span class="ml-3 text-sm text-text-primary">Réponse < 24h</span>
                                </label>
                            </div>
                        </div>

                        <!-- Bouton réinitialiser -->
                        <?php if(request()->hasAny(['offer_type', 'price_range', 'with_reviews', 'type', 'destination', 'rating'])): ?>
                            <div class="pt-4 border-t border-border">
                                <a href="<?php echo e(route('vendors.index')); ?>" class="block text-center px-4 py-2 bg-bg-alt text-text-primary rounded-md hover:bg-gray-200 transition-colors">
                                    Réinitialiser les filtres
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Liste principale -->
            <div class="lg:col-span-3">
                <!-- Header avec tri -->
                <div class="bg-white rounded-lg shadow-sm p-4 mb-6">
                    <div class="flex items-center justify-between">
                        <h2 class="text-lg font-semibold text-text-primary">
                            <?php echo e($vendors->total()); ?> organisateur<?php echo e($vendors->total() > 1 ? 's' : ''); ?> trouvé<?php echo e($vendors->total() > 1 ? 's' : ''); ?>

                        </h2>
                        <select name="sort" onchange="window.location.href='<?php echo e(route('vendors.index')); ?>?sort=' + this.value + '&<?php echo e(http_build_query(request()->except('sort'))); ?>'"
                                class="text-sm border border-border rounded-md py-1 px-2 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary">
                            <option value="recommended" <?php echo e(request('sort', 'recommended') == 'recommended' ? 'selected' : ''); ?>>Recommandés</option>
                            <option value="rating" <?php echo e(request('sort') == 'rating' ? 'selected' : ''); ?>>Mieux notés</option>
                            <option value="trips" <?php echo e(request('sort') == 'trips' ? 'selected' : ''); ?>>Plus d'offres</option>
                            <option value="recent" <?php echo e(request('sort') == 'recent' ? 'selected' : ''); ?>>Plus récents</option>
                        </select>
                    </div>
                </div>

                <!-- Grid des organisateurs -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php $__empty_1 = true; $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                            <div class="p-6">
                                <!-- Profil et infos principales -->
                                <div class="flex items-start space-x-4">
                                    <!-- Photo de profil -->
                                    <div class="relative flex-shrink-0">
                                        <?php if($vendor->logo): ?>
                                            <img src="<?php echo e($vendor->logo_url); ?>" alt="<?php echo e($vendor->company_name); ?>" 
                                                 class="h-20 w-20 rounded-full object-cover border-2 border-gray-200">
                                        <?php else: ?>
                                            <div class="h-20 w-20 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center border-2 border-gray-200">
                                                <span class="text-2xl font-bold text-primary"><?php echo e(strtoupper(substr($vendor->company_name, 0, 2))); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($vendor->subscription_plan === 'pro'): ?>
                                            <div class="absolute -bottom-1 -right-1 bg-gradient-to-r from-yellow-400 to-yellow-600 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                                                PRO
                                            </div>
                                        <?php elseif($vendor->subscription_plan === 'essential'): ?>
                                            <div class="absolute -bottom-1 -right-1 bg-gradient-to-r from-primary to-primary-dark text-white text-xs font-bold px-2 py-0.5 rounded-full">
                                                Essential
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Infos principales -->
                                    <div class="flex-1">
                                        <div class="flex items-start justify-between">
                                            <div>
                                                <h3 class="text-lg font-bold text-text-primary"><?php echo e($vendor->company_name); ?></h3>
                                                <div class="flex items-center text-sm text-text-secondary mt-1">
                                                    <svg class="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                                                    </svg>
                                                    <span><?php echo e($vendor->city ?? 'France'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Note et avis seulement si il y a une note -->
                                        <?php if($vendor->average_rating > 0): ?>
                                            <div class="flex items-center mt-2">
                                                <div class="flex">
                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <?php if($i <= floor($vendor->average_rating)): ?>
                                                            <svg class="h-4 w-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                                                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                                            </svg>
                                                        <?php else: ?>
                                                            <svg class="h-4 w-4 text-gray-300" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 20 20">
                                                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                                            </svg>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </div>
                                                <span class="ml-2 text-sm font-bold text-text-primary"><?php echo e(number_format($vendor->average_rating, 1)); ?></span>
                                                <?php if($vendor->total_reviews > 0): ?>
                                                    <span class="ml-1 text-sm text-text-secondary">(<?php echo e($vendor->total_reviews); ?> avis)</span>
                                                <?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-sm text-text-secondary italic mt-2">Pas encore d'avis</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Description -->
                                <?php if($vendor->description): ?>
                                    <p class="text-sm text-text-secondary line-clamp-2 mt-4">
                                        <?php echo e($vendor->description); ?>

                                    </p>
                                <?php endif; ?>
                                
                                <!-- Tags de compétences -->
                                <div class="flex flex-wrap gap-2 mt-4">
                                    <span class="inline-block bg-primary/10 text-primary text-xs font-medium px-2 py-1 rounded">
                                        Séjours organisés
                                    </span>
                                    <span class="inline-block bg-primary/10 text-primary text-xs font-medium px-2 py-1 rounded">
                                        Sur mesure
                                    </span>
                                    <?php if($vendor->countries && $vendor->countries->count() > 0): ?>
                                        <span class="inline-block bg-gray-100 text-text-secondary text-xs font-medium px-2 py-1 rounded">
                                            <?php echo e($vendor->countries->count()); ?> destination<?php echo e($vendor->countries->count() > 1 ? 's' : ''); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Footer avec stats et CTA -->
                                <div class="pt-4 mt-4 border-t border-border flex items-center justify-between">
                                    <div class="flex items-center gap-4 text-sm">
                                        <div class="flex items-center text-text-secondary">
                                            <svg class="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                                            </svg>
                                            <span class="font-medium text-text-primary"><?php echo e($vendor->trips_count ?? 0); ?></span>
                                            <span class="ml-1">offres</span>
                                        </div>
                                        <div class="flex items-center text-text-secondary">
                                            <svg class="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                            </svg>
                                            <span>< 24h</span>
                                        </div>
                                    </div>
                                    
                                    <a href="<?php echo e(route('vendors.show', $vendor->slug ?: $vendor->id)); ?>" 
                                       class="inline-flex items-center px-4 py-2 bg-primary hover:bg-primary-dark text-white text-sm font-medium rounded-lg transition-all duration-300 hover:shadow-lg">
                                        Voir le profil
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-span-2">
                            <div class="bg-white rounded-lg shadow-sm p-12 text-center">
                                <div class="h-16 w-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                                    <svg class="h-8 w-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                                    </svg>
                                </div>
                                <h3 class="text-xl font-semibold text-text-primary mb-2">Aucun organisateur trouvé</h3>
                                <p class="text-text-secondary mb-6">Modifiez vos critères de recherche pour voir plus de résultats</p>
                                <a href="<?php echo e(route('vendors.index')); ?>" class="inline-flex items-center px-4 py-2 bg-primary hover:bg-primary-dark text-white font-medium rounded-md transition-colors">
                                    Réinitialiser les filtres
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Pagination -->
                <?php if($vendors->hasPages()): ?>
                    <div class="mt-8">
                        <?php echo e($vendors->withQueryString()->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- CTA Section -->
    <div class="bg-gradient-to-r from-primary to-primary-dark py-16">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 class="text-3xl font-bold text-white mb-4">Devenez organisateur sur Nomadie</h2>
            <p class="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
                Rejoignez notre communauté et développez votre activité
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="<?php echo e(route('vendor.register')); ?>" class="inline-flex items-center justify-center px-6 py-3 bg-white text-primary hover:bg-gray-100 font-medium rounded-md shadow-sm transition-colors">
                    Créer un compte professionnel
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                </a>
                <a href="<?php echo e(route('contact')); ?>" class="inline-flex items-center justify-center px-6 py-3 border border-white text-white hover:bg-white/10 font-medium rounded-md transition-colors">
                    En savoir plus
                </a>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .line-clamp-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Mise à jour de la valeur du slider de prix
    document.getElementById('price-range')?.addEventListener('input', function(e) {
        document.getElementById('price-value').textContent = e.target.value + '€';
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/index.blade.php ENDPATH**/ ?>