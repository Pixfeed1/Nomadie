

<?php $__env->startSection('title', 'Analytics'); ?>

<?php $__env->startSection('page-title', 'Analytics'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-white rounded-lg shadow-sm overflow-hidden card">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Revenus totaux</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e(number_format($detailedStats['total_revenue'] ?? 0, 0, ',', ' ')); ?> €</p>
                    <p class="text-xs text-success font-medium flex items-center mt-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                        </svg>
                        +<?php echo e($detailedStats['revenue_growth'] ?? 0); ?>% ce mois
                    </p>
                </div>
                <div class="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm overflow-hidden card">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Réservations</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e($detailedStats['total_bookings'] ?? 0); ?></p>
                    <p class="text-xs text-success font-medium flex items-center mt-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                        </svg>
                        +<?php echo e($detailedStats['booking_growth'] ?? 0); ?>% ce mois
                    </p>
                </div>
                <div class="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm overflow-hidden card">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Taux conversion</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e($detailedStats['conversion_rate'] ?? 0); ?>%</p>
                    <p class="text-xs <?php echo e(($detailedStats['conversion_change'] ?? 0) >= 0 ? 'text-success' : 'text-error'); ?> font-medium flex items-center mt-2">
                        <?php if(($detailedStats['conversion_change'] ?? 0) >= 0): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                            </svg>
                        <?php else: ?>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" />
                            </svg>
                        <?php endif; ?>
                        <?php echo e(abs($detailedStats['conversion_change'] ?? 0)); ?>% vs mois dernier
                    </p>
                </div>
                <div class="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm overflow-hidden card">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Note moyenne</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e(number_format($detailedStats['average_rating'] ?? 0, 1)); ?>/5</p>
                    <div class="flex items-center mt-2">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <svg class="h-4 w-4 <?php echo e($i <= ($detailedStats['average_rating'] ?? 0) ? 'text-yellow-400' : 'text-gray-300'); ?>" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                        <?php endfor; ?>
                    </div>
                </div>
                <div class="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <!-- Graphiques principaux -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Évolution des revenus -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-6 border-b border-border">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-text-primary">Évolution des revenus</h3>
                    <select class="text-sm border border-border rounded-lg px-3 py-1 focus:outline-none focus:ring-2 focus:ring-primary/20">
                        <option>12 derniers mois</option>
                        <option>6 derniers mois</option>
                        <option>3 derniers mois</option>
                    </select>
                </div>
            </div>
            <div class="p-6">
                <canvas id="revenueChart" height="300"></canvas>
            </div>
        </div>

        <!-- Répartition par destination -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-6 border-b border-border">
                <h3 class="text-lg font-semibold text-text-primary">Top destinations</h3>
                <p class="text-sm text-text-secondary mt-1">Vos destinations les plus populaires</p>
            </div>
            <div class="p-6">
                <?php if(isset($detailedStats['top_destinations']) && count($detailedStats['top_destinations']) > 0): ?>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $detailedStats['top_destinations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center justify-between">
                                <div class="flex items-center flex-1">
                                    <div class="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center mr-3">
                                        <span class="text-xs font-bold text-primary"><?php echo e(substr($destination['name'], 0, 2)); ?></span>
                                    </div>
                                    <div class="flex-1">
                                        <div class="flex items-center justify-between mb-1">
                                            <span class="text-sm font-medium text-text-primary"><?php echo e($destination['name']); ?></span>
                                            <span class="text-sm text-text-secondary"><?php echo e($destination['bookings']); ?> réservations</span>
                                        </div>
                                        <div class="w-full bg-gray-200 rounded-full h-2">
                                            <div class="bg-primary h-2 rounded-full" style="width: <?php echo e($destination['percentage']); ?>%"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8">
                        <div class="h-16 w-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                            <svg class="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <p class="text-gray-500">Aucune donnée disponible</p>
                        <p class="text-sm text-gray-400 mt-1">Les statistiques apparaîtront ici après vos premières réservations</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Performances détaillées -->
    <div class="bg-white rounded-lg shadow-sm overflow-hidden">
        <div class="p-6 border-b border-border">
            <h3 class="text-lg font-semibold text-text-primary">Performances détaillées</h3>
            <p class="text-sm text-text-secondary mt-1">Analyse approfondie de vos voyages</p>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-border">
                <thead class="bg-bg-alt">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                            Voyage
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                            Destination
                        </th>
                        <th class="px-6 py-3 text-center text-xs font-medium text-text-secondary uppercase tracking-wider">
                            Réservations
                        </th>
                        <th class="px-6 py-3 text-center text-xs font-medium text-text-secondary uppercase tracking-wider">
                            Taux remplissage
                        </th>
                        <th class="px-6 py-3 text-center text-xs font-medium text-text-secondary uppercase tracking-wider">
                            Revenus
                        </th>
                        <th class="px-6 py-3 text-center text-xs font-medium text-text-secondary uppercase tracking-wider">
                            Note
                        </th>
                        <th class="px-6 py-3 text-center text-xs font-medium text-text-secondary uppercase tracking-wider">
                            Statut
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-border">
                    <?php $__empty_1 = true; $__currentLoopData = $detailedStats['trips_performance'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-bg-alt/30 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-text-primary"><?php echo e($trip['title']); ?></div>
                                <div class="text-xs text-text-secondary"><?php echo e($trip['duration']); ?> jours</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                                        <span class="text-xs font-medium text-primary"><?php echo e(substr($trip['destination'], 0, 2)); ?></span>
                                    </div>
                                    <span class="text-sm text-text-primary"><?php echo e($trip['destination']); ?></span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <span class="text-sm font-medium text-text-primary"><?php echo e($trip['bookings']); ?></span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <div class="flex items-center justify-center">
                                    <span class="text-sm font-medium <?php echo e($trip['fill_rate'] >= 80 ? 'text-success' : ($trip['fill_rate'] >= 50 ? 'text-accent' : 'text-error')); ?>">
                                        <?php echo e($trip['fill_rate']); ?>%
                                    </span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <span class="text-sm font-medium text-text-primary"><?php echo e(number_format($trip['revenue'], 0, ',', ' ')); ?> €</span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <div class="flex items-center justify-center">
                                    <span class="text-sm font-medium text-text-primary mr-1"><?php echo e(number_format($trip['rating'], 1)); ?></span>
                                    <svg class="h-4 w-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                    <?php echo e($trip['status'] === 'active' ? 'bg-success/15 text-success' : 'bg-gray-100 text-gray-600'); ?>">
                                    <?php echo e($trip['status'] === 'active' ? 'Actif' : 'Inactif'); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center">
                                    <div class="h-16 w-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                                        <svg class="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                        </svg>
                                    </div>
                                    <p class="text-gray-500 font-medium">Aucun voyage actif</p>
                                    <p class="text-sm text-gray-400 mt-1">Créez votre premier voyage pour voir les statistiques</p>
                                    <a href="<?php echo e(route('vendor.trips.create')); ?>" class="mt-4 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors text-sm">
                                        Créer un voyage
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Conseils de performance -->
    <div class="bg-white rounded-lg shadow-sm overflow-hidden">
        <div class="p-6 border-b border-border">
            <h3 class="text-lg font-semibold text-text-primary">Conseils pour améliorer vos performances</h3>
        </div>
        <div class="p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <?php
                    $tips = [
                        [
                            'icon' => 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z',
                            'title' => 'Ajoutez des photos de qualité',
                            'description' => 'Les voyages avec 5+ photos ont 40% plus de réservations',
                            'status' => 'warning'
                        ],
                        [
                            'icon' => 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
                            'title' => 'Optimisez vos prix',
                            'description' => 'Réduisez vos prix de 10% pour augmenter les réservations',
                            'status' => 'info'
                        ],
                        [
                            'icon' => 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
                            'title' => 'Proposez plus de dates',
                            'description' => 'Les voyages avec 10+ dates ont 3x plus de chances d\'être réservés',
                            'status' => 'success'
                        ],
                        [
                            'icon' => 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z',
                            'title' => 'Répondez rapidement aux avis',
                            'description' => 'Les vendeurs qui répondent sous 24h ont 20% de réservations en plus',
                            'status' => 'primary'
                        ]
                    ];
                    $statusColors = [
                        'warning' => 'bg-accent/5 border-accent/20',
                        'info' => 'bg-blue-50 border-blue-200',
                        'success' => 'bg-success/5 border-success/20',
                        'primary' => 'bg-primary/5 border-primary/20'
                    ];
                    $iconColors = [
                        'warning' => 'bg-accent/10 text-accent',
                        'info' => 'bg-blue-100 text-blue-600',
                        'success' => 'bg-success/10 text-success',
                        'primary' => 'bg-primary/10 text-primary'
                    ];
                ?>

                <?php $__currentLoopData = $tips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-start p-4 rounded-lg border <?php echo e($statusColors[$tip['status']]); ?>">
                        <div class="flex-shrink-0">
                            <div class="h-10 w-10 rounded-full <?php echo e($iconColors[$tip['status']]); ?> flex items-center justify-center">
                                <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($tip['icon']); ?>" />
                                </svg>
                            </div>
                        </div>
                        <div class="ml-4">
                            <h4 class="text-sm font-medium text-text-primary"><?php echo e($tip['title']); ?></h4>
                            <p class="text-xs text-text-secondary mt-1"><?php echo e($tip['description']); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Graphique des revenus
    const ctx = document.getElementById('revenueChart').getContext('2d');
    const revenueChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($yearlyData['months'] ?? ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc']); ?>,
            datasets: [{
                label: 'Revenus (€)',
                data: <?php echo json_encode($yearlyData['revenue'] ?? [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]); ?>,
                borderColor: '#38B2AC',
                backgroundColor: 'rgba(56, 178, 172, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value + ' €';
                        }
                    }
                }
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .card {
        transition: all 0.3s ease;
    }
    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/dashboard/analytics.blade.php ENDPATH**/ ?>