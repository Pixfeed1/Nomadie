

<?php $__env->startSection('content'); ?>
    
    <?php if (! empty(trim($__env->yieldContent('dashboard-stats')))): ?>
        <?php echo $__env->yieldContent('dashboard-stats'); ?>
    <?php endif; ?>

    
    <div class="space-y-6">
        <?php echo $__env->yieldContent('dashboard-content'); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('customer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/customer/layouts/dashboard.blade.php ENDPATH**/ ?>