<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - Dashboard Organisateur | Marketplace Voyages</title>
    
    <!-- Intégration de Vite pour les assets compilés -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Chart.js pour les graphiques -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Styles personnalisés -->
    <style>
        [x-cloak] { display: none !important; }
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
        }
        
        .btn {
            transition: all 0.2s ease;
        }
        
        .btn:hover {
            transform: translateY(-1px);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .card:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.05);
        }
        
        /* Sidebar animations */
        .sidebar-transition {
            transition: transform 0.3s ease-in-out;
        }
        
        /* Stats cards hover effects */
        .stats-card {
            transition: all 0.3s ease;
        }
        
        .stats-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        /* Navigation active states */
        .nav-active {
            background: linear-gradient(90deg, var(--color-primary, #3b82f6), var(--color-primary-dark, #2563eb));
            color: white !important;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        .nav-active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: var(--color-accent, #f59e0b);
        }
    </style>
    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body x-data="{ sidebarOpen: false }" class="bg-gray-50">
    <div class="min-h-screen flex">
        <!-- Sidebar pour desktop -->
        <div class="hidden lg:flex lg:flex-shrink-0">
            <div class="flex flex-col w-64">
                <div class="flex flex-col flex-grow bg-white border-r border-gray-200 pt-5 pb-4 overflow-y-auto">
                    <!-- Logo -->
                    <div class="flex items-center flex-shrink-0 px-4">
                        <a href="<?php echo e(route('vendor.dashboard.index')); ?>" class="flex items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-primary mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <div>
                                <span class="text-lg font-bold text-text-primary">Marketplace</span>
                                <span class="block text-xs text-text-secondary">Dashboard Organisateur</span>
                            </div>
                        </a>
                    </div>
                    
                    <!-- Informations vendeur -->
                    <div class="mt-5 px-4">
                        <div class="bg-primary/10 rounded-lg p-3">
                            <div class="flex items-center">
                                <?php if(Auth::user()->vendor->logo): ?>
                                    <img src="<?php echo e(asset('storage/' . Auth::user()->vendor->logo)); ?>" 
                                         alt="Logo" class="h-10 w-10 rounded-lg object-cover">
                                <?php else: ?>
                                    <div class="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                                        <svg class="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                        </svg>
                                    </div>
                                <?php endif; ?>
                                <div class="ml-3 flex-1 min-w-0">
                                    <p class="text-sm font-medium text-text-primary truncate">
                                        <?php echo e(Auth::user()->vendor->company_name); ?>

                                    </p>
                                    <p class="text-xs text-text-secondary">
                                        Plan <?php echo e(ucfirst(Auth::user()->vendor->subscription_plan)); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Navigation -->
                    <nav class="mt-5 flex-1 px-2 space-y-1">
                        <a href="<?php echo e(route('vendor.dashboard.index')); ?>" 
                           class="relative group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors
                                  <?php echo e(request()->routeIs('vendor.dashboard.index') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5v4" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v4" />
                            </svg>
                            Dashboard
                        </a>

                        <a href="<?php echo e(route('vendor.trips.index')); ?>" 
                           class="relative group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors
                                  <?php echo e(request()->routeIs('vendor.trips.*') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                            Mes Offres
                            <?php if(Auth::user()->vendor->trips()->count() > 0): ?>
                                <span class="ml-auto bg-primary/20 text-primary text-xs px-2 py-1 rounded-full">
                                    <?php echo e(Auth::user()->vendor->trips()->count()); ?>

                                </span>
                            <?php endif; ?>
                        </a>

                        <!-- NOUVEAU MENU MESSAGES -->
                        <a href="<?php echo e(route('vendor.messages.index')); ?>" 
                           class="relative group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors
                                  <?php echo e(request()->routeIs('vendor.messages.*') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                            </svg>
                            Messages
                            <?php
                                $unreadCount = \App\Models\Message::where('recipient_id', Auth::id())
                                    ->where('is_read', false)
                                    ->count();
                            ?>
                            <?php if($unreadCount > 0): ?>
                                <span class="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                                    <?php echo e($unreadCount > 9 ? '9+' : $unreadCount); ?>

                                </span>
                            <?php endif; ?>
                        </a>

                        <a href="<?php echo e(route('vendor.bookings.index')); ?>" 
                           class="relative group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors
                                  <?php echo e(request()->routeIs('vendor.bookings.*') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z" />
                            </svg>
                            Réservations
                        </a>

                        <a href="<?php echo e(route('vendor.dashboard.analytics')); ?>" 
                           class="relative group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors
                                  <?php echo e(request()->routeIs('vendor.dashboard.analytics') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                            </svg>
                            Analytiques
                        </a>

                        <a href="<?php echo e(route('vendor.payments.index')); ?>" 
                           class="relative group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors
                                  <?php echo e(request()->routeIs('vendor.payments.*') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15l1 1 4-4m6 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2V9a2 2 0 012-2h11l3 3z" />
                            </svg>
                            Paiements
                        </a>

                        <!-- Divider -->
                        <hr class="my-3 border-gray-200">

                        <a href="<?php echo e(route('vendor.settings.index')); ?>" 
                           class="relative group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors
                                  <?php echo e(request()->routeIs('vendor.settings.*') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                            Paramètres
                        </a>

                        <a href="<?php echo e(route('home')); ?>" 
                           class="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-text-secondary hover:text-primary hover:bg-primary/5 transition-colors">
                            <svg class="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                            </svg>
                            Voir le site
                        </a>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Contenu principal -->
        <div class="flex-1 overflow-hidden">
            <!-- Header mobile -->
            <div class="lg:hidden">
                <div class="flex items-center justify-between bg-white px-4 py-2 border-b border-gray-200">
                    <div class="flex items-center">
                        <button @click="sidebarOpen = true" class="text-gray-500 hover:text-primary">
                            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                            </svg>
                        </button>
                        <h1 class="ml-3 text-lg font-semibold text-text-primary">Dashboard</h1>
                    </div>
                    <div class="flex items-center space-x-2">
                        <!-- Notifications -->
                        <button class="p-2 text-gray-400 hover:text-primary">
                            <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                            </svg>
                        </button>
                        <!-- Profile -->
                        <div class="flex items-center">
                            <?php if(Auth::user()->vendor->logo): ?>
                                <img src="<?php echo e(asset('storage/' . Auth::user()->vendor->logo)); ?>" 
                                     alt="Logo" class="h-8 w-8 rounded-lg object-cover">
                            <?php else: ?>
                                <div class="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center">
                                    <svg class="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                    </svg>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Header desktop -->
            <header class="hidden lg:block bg-white shadow-sm border-b border-gray-200">
                <div class="px-6 py-4">
                    <div class="flex items-center justify-between">
                        <div>
                            <h1 class="text-2xl font-bold text-text-primary"><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h1>
                            <p class="text-text-secondary"><?php echo $__env->yieldContent('page-description', 'Gérez vos offres et votre activité'); ?></p>
                        </div>
                        <div class="flex items-center space-x-4">
                            <!-- Notifications -->
                            <button class="relative p-2 text-gray-400 hover:text-primary transition-colors">
                                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                                </svg>
                                <?php
                                    $totalUnread = \App\Models\Message::where('recipient_id', Auth::id())
                                        ->where('is_read', false)
                                        ->count();
                                ?>
                                <?php if($totalUnread > 0): ?>
                                    <span class="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400"></span>
                                <?php endif; ?>
                            </button>

                            <!-- Profile Dropdown -->
                            <div x-data="{ open: false }" class="relative">
                                <button @click="open = !open" class="flex items-center text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-primary transition-all">
                                    <span class="sr-only">Ouvrir le menu utilisateur</span>
                                    <?php if(Auth::user()->vendor->logo): ?>
                                        <img src="<?php echo e(asset('storage/' . Auth::user()->vendor->logo)); ?>" 
                                             alt="Logo" class="h-8 w-8 rounded-lg object-cover">
                                    <?php else: ?>
                                        <div class="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center">
                                            <svg class="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                            </svg>
                                        </div>
                                    <?php endif; ?>
                                    <span class="ml-2 text-text-primary font-medium"><?php echo e(Auth::user()->name); ?></span>
                                    <svg class="ml-1 h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                                    </svg>
                                </button>

                                <div x-show="open" 
                                     @click.away="open = false" 
                                     x-transition:enter="transition ease-out duration-100"
                                     x-transition:enter-start="transform opacity-0 scale-95"
                                     x-transition:enter-end="transform opacity-100 scale-100"
                                     x-transition:leave="transition ease-in duration-75"
                                     x-transition:leave-start="transform opacity-100 scale-100"
                                     x-transition:leave-end="transform opacity-0 scale-95"
                                     class="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-50"
                                     x-cloak>
                                    <div class="py-1">
                                        <a href="<?php echo e(route('vendor.settings.index')); ?>" class="block px-4 py-2 text-sm text-text-secondary hover:bg-gray-100 hover:text-text-primary">
                                            <svg class="inline h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                            </svg>
                                            Paramètres
                                        </a>
                                        <a href="<?php echo e(route('home')); ?>" class="block px-4 py-2 text-sm text-text-secondary hover:bg-gray-100 hover:text-text-primary">
                                            <svg class="inline h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                            </svg>
                                            Voir le site
                                        </a>
                                        <div class="border-t border-gray-100"></div>
                                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="w-full text-left block px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                                                <svg class="inline h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                                </svg>
                                                Déconnexion
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Messages flash -->
            <?php if(session('success')): ?>
                <div x-data="{ show: true }" 
                     x-show="show" 
                     x-init="setTimeout(() => show = false, 5000)" 
                     x-transition:enter="transition ease-out duration-300"
                     x-transition:enter-start="opacity-0 transform translate-y-2"
                     x-transition:enter-end="opacity-100 transform translate-y-0"
                     x-transition:leave="transition ease-in duration-200"
                     x-transition:leave-start="opacity-100 transform translate-y-0"
                     x-transition:leave-end="opacity-0 transform translate-y-2"
                     class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 m-4 rounded-lg">
                    <div class="flex">
                        <svg class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span><?php echo e(session('success')); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div x-data="{ show: true }" 
                     x-show="show" 
                     x-init="setTimeout(() => show = false, 5000)"
                     x-transition:enter="transition ease-out duration-300"
                     x-transition:enter-start="opacity-0 transform translate-y-2"
                     x-transition:enter-end="opacity-100 transform translate-y-0"
                     x-transition:leave="transition ease-in duration-200"
                     x-transition:leave-start="opacity-100 transform translate-y-0"
                     x-transition:leave-end="opacity-0 transform translate-y-2"
                     class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 m-4 rounded-lg">
                    <div class="flex">
                        <svg class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span><?php echo e(session('error')); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(session('warning')): ?>
                <div x-data="{ show: true }" 
                     x-show="show" 
                     x-init="setTimeout(() => show = false, 5000)"
                     x-transition:enter="transition ease-out duration-300"
                     x-transition:enter-start="opacity-0 transform translate-y-2"
                     x-transition:enter-end="opacity-100 transform translate-y-0"
                     x-transition:leave="transition ease-in duration-200"
                     x-transition:leave-start="opacity-100 transform translate-y-0"
                     x-transition:leave-end="opacity-0 transform translate-y-2"
                     class="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 m-4 rounded-lg">
                    <div class="flex">
                        <svg class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                        <span><?php echo e(session('warning')); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Contenu principal -->
            <main class="flex-1 overflow-y-auto">
                <div class="p-6">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
        </div>

        <!-- Sidebar mobile -->
        <div x-show="sidebarOpen" class="fixed inset-0 flex z-40 lg:hidden" x-cloak>
            <!-- Overlay -->
            <div x-show="sidebarOpen" 
                 x-transition:enter="transition-opacity ease-linear duration-300"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition-opacity ease-linear duration-300"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 @click="sidebarOpen = false" 
                 class="fixed inset-0 bg-gray-600 bg-opacity-75"></div>

            <!-- Sidebar -->
            <div x-show="sidebarOpen"
                 x-transition:enter="transition ease-in-out duration-300 transform"
                 x-transition:enter-start="-translate-x-full"
                 x-transition:enter-end="translate-x-0"
                 x-transition:leave="transition ease-in-out duration-300 transform"
                 x-transition:leave-start="translate-x-0"
                 x-transition:leave-end="-translate-x-full"
                 class="relative flex-1 flex flex-col max-w-xs w-full bg-white">
                
                <!-- Close button -->
                <div class="absolute top-0 right-0 -mr-12 pt-2">
                    <button @click="sidebarOpen = false" 
                            class="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                        <svg class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>

                <!-- Contenu identique au sidebar desktop -->
                <div class="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
                    <!-- Logo mobile -->
                    <div class="flex items-center flex-shrink-0 px-4">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-primary mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <div>
                            <span class="text-lg font-bold text-text-primary">Marketplace</span>
                            <span class="block text-xs text-text-secondary">Dashboard</span>
                        </div>
                    </div>

                    <!-- Navigation mobile (identique) -->
                    <nav class="mt-5 px-2 space-y-1">
                        <a href="<?php echo e(route('vendor.dashboard.index')); ?>" 
                           @click="sidebarOpen = false"
                           class="group flex items-center px-2 py-2 text-base font-medium rounded-md <?php echo e(request()->routeIs('vendor.dashboard.index') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-4 h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z" />
                            </svg>
                            Dashboard
                        </a>

                        <a href="<?php echo e(route('vendor.trips.index')); ?>" 
                           @click="sidebarOpen = false"
                           class="group flex items-center px-2 py-2 text-base font-medium rounded-md <?php echo e(request()->routeIs('vendor.trips.*') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-4 h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            </svg>
                            Mes Offres
                        </a>

                        <!-- NOUVEAU MENU MESSAGES MOBILE -->
                        <a href="<?php echo e(route('vendor.messages.index')); ?>" 
                           @click="sidebarOpen = false"
                           class="group flex items-center px-2 py-2 text-base font-medium rounded-md <?php echo e(request()->routeIs('vendor.messages.*') ? 'nav-active' : 'text-text-secondary hover:text-primary hover:bg-primary/5'); ?>">
                            <svg class="mr-4 h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                            </svg>
                            Messages
                            <?php
                                $unreadMobile = \App\Models\Message::where('recipient_id', Auth::id())
                                    ->where('is_read', false)
                                    ->count();
                            ?>
                            <?php if($unreadMobile > 0): ?>
                                <span class="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                                    <?php echo e($unreadMobile); ?>

                                </span>
                            <?php endif; ?>
                        </a>

                        <!-- Autres liens de navigation mobile -->
                        <a href="<?php echo e(route('vendor.settings.index')); ?>" 
                           @click="sidebarOpen = false"
                           class="group flex items-center px-2 py-2 text-base font-medium rounded-md text-text-secondary hover:text-primary hover:bg-primary/5">
                            <svg class="mr-4 h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                            </svg>
                            Paramètres
                        </a>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/layouts/app.blade.php ENDPATH**/ ?>