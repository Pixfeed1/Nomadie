<?php $__env->startSection('title', $trip->title . ' - Détails'); ?>

<?php $__env->startSection('page-title'); ?>
<div class="flex items-center justify-between">
    <div>
        <h1 class="text-2xl font-bold text-text-primary"><?php echo e($trip->title); ?></h1>
        <p class="text-sm text-text-secondary mt-1">
            <?php if($trip->destination && is_object($trip->destination)): ?>
                <?php echo e($trip->destination->name); ?>

                <?php if($trip->destination->country && is_object($trip->destination->country)): ?>
                    , <?php echo e($trip->destination->country->name); ?>

                <?php endif; ?>
            <?php else: ?>
                Destination non définie
            <?php endif; ?>
        </p>
    </div>
    <div class="flex items-center space-x-2">
        <?php if($trip->status === 'active'): ?>
            <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-success/15 text-success">
                Actif
            </span>
        <?php elseif($trip->status === 'draft'): ?>
            <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-600">
                Brouillon
            </span>
        <?php else: ?>
            <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-error/15 text-error">
                Inactif
            </span>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Actions rapides -->
    <div class="bg-white rounded-lg shadow-sm p-4">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-3 sm:space-y-0">
            <div class="flex items-center space-x-4">
                <a href="<?php echo e(route('vendor.trips.index')); ?>" class="flex items-center text-text-secondary hover:text-text-primary transition-colors">
                    <svg class="h-5 w-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                    </svg>
                    Retour aux offres
                </a>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="<?php echo e(route('vendor.trips.availabilities.index', $trip)); ?>" 
                   class="inline-flex items-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors">
                    <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                    Gérer les disponibilités
                </a>
                <a href="<?php echo e(route('vendor.trips.edit', $trip)); ?>" 
                   class="inline-flex items-center px-4 py-2 bg-white border border-border text-text-primary rounded-lg hover:bg-bg-alt transition-colors">
                    <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                    </svg>
                    Modifier
                </a>
                <button onclick="if(confirm('Êtes-vous sûr de vouloir dupliquer cette offre ?')) { document.getElementById('duplicate-form').submit(); }"
                        class="inline-flex items-center px-4 py-2 bg-white border border-border text-text-primary rounded-lg hover:bg-bg-alt transition-colors">
                    <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2"/>
                    </svg>
                    Dupliquer
                </button>
                <form id="duplicate-form" action="<?php echo e(route('vendor.trips.duplicate', $trip)); ?>" method="POST" class="hidden">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </div>

    <!-- Statistiques rapides -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs text-text-secondary uppercase font-medium">Vues</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e(number_format($tripStats['views'])); ?></p>
                </div>
                <div class="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <svg class="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs text-text-secondary uppercase font-medium">Réservations</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e(number_format($tripStats['bookings'])); ?></p>
                </div>
                <div class="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                    <svg class="h-5 w-5 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs text-text-secondary uppercase font-medium">Revenus</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e(number_format($tripStats['revenue'], 0, ',', ' ')); ?> €</p>
                </div>
                <div class="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                    <svg class="h-5 w-5 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs text-text-secondary uppercase font-medium">Places disponibles</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e(number_format($tripStats['available_spots'])); ?></p>
                </div>
                <div class="h-10 w-10 rounded-full bg-primary-dark/10 flex items-center justify-center">
                    <svg class="h-5 w-5 text-primary-dark" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs text-text-secondary uppercase font-medium">Note</p>
                    <p class="text-2xl font-bold text-text-primary mt-1">
                        <?php if($trip->rating > 0): ?>
                            <?php echo e(number_format($trip->rating, 1)); ?>/5
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </p>
                </div>
                <div class="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center">
                    <svg class="h-5 w-5 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <!-- Contenu principal -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Colonne principale -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Galerie d'images -->
            <?php if($trip->images && count($trip->images) > 0): ?>
            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <div class="p-6 border-b border-border">
                    <h3 class="text-lg font-semibold text-text-primary">Galerie photos</h3>
                </div>
                <div class="p-6">
                    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                        <?php $__currentLoopData = $trip->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="relative group aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
                            <img src="<?php echo e(Storage::url($image['path'])); ?>" 
                                 alt="<?php echo e($image['caption'] ?? 'Image ' . ($index + 1)); ?>"
                                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                            <div class="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                                <button onclick="openImageModal('<?php echo e(Storage::url($image['path'])); ?>')" 
                                        class="p-2 bg-white/90 rounded-full text-text-primary hover:bg-white transition-colors">
                                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Informations détaillées -->
            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <div class="p-6 border-b border-border">
                    <h3 class="text-lg font-semibold text-text-primary">Informations détaillées</h3>
                </div>
                <div class="p-6 space-y-6">
                    <!-- Type et tarification -->
                    <div>
                        <h4 class="text-sm font-medium text-text-secondary uppercase mb-3">Type d'offre</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="p-4 bg-bg-alt rounded-lg">
                                <p class="text-sm text-text-secondary">Type</p>
                                <p class="font-medium text-text-primary">
                                    <?php if($trip->type === 'fixed'): ?>
                                        Séjour fixe
                                    <?php elseif($trip->type === 'circuit'): ?>
                                        Circuit
                                    <?php elseif($trip->type === 'activity'): ?>
                                        Activité
                                    <?php else: ?>
                                        <?php echo e(ucfirst($trip->type)); ?>

                                    <?php endif; ?>
                                </p>
                            </div>
                            <div class="p-4 bg-bg-alt rounded-lg">
                                <p class="text-sm text-text-secondary">Mode de tarification</p>
                                <p class="font-medium text-text-primary">
                                    <?php if($trip->pricing_mode === 'per_person_full_stay'): ?>
                                        Par personne (séjour complet)
                                    <?php elseif($trip->pricing_mode === 'per_night_property'): ?>
                                        Par nuit (logement entier)
                                    <?php elseif($trip->pricing_mode === 'per_person_activity'): ?>
                                        Par personne (activité)
                                    <?php elseif($trip->pricing_mode === 'per_group'): ?>
                                        Par groupe
                                    <?php elseif($trip->pricing_mode === 'per_person_per_day'): ?>
                                        Par personne par jour
                                    <?php else: ?>
                                        <?php echo e($trip->getPricingModeTextAttribute() ?? 'Par personne'); ?>

                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Description -->
                    <div>
                        <h4 class="text-sm font-medium text-text-secondary uppercase mb-3">Description</h4>
                        <div class="prose prose-sm max-w-none">
                            <p class="text-text-primary font-medium mb-2"><?php echo e($trip->short_description); ?></p>
                            <div class="text-text-secondary whitespace-pre-wrap"><?php echo e($trip->description); ?></div>
                        </div>
                    </div>

                    <!-- Détails pratiques -->
                    <div>
                        <h4 class="text-sm font-medium text-text-secondary uppercase mb-3">Détails pratiques</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <p class="text-sm text-text-secondary mb-1">Durée</p>
                                <p class="font-medium text-text-primary">
                                    <?php if($trip->duration_hours): ?>
                                        <?php echo e($trip->duration_hours); ?> heures
                                    <?php else: ?>
                                        <?php echo e($trip->duration); ?> jours
                                    <?php endif; ?>
                                </p>
                            </div>
                            <div>
                                <p class="text-sm text-text-secondary mb-1">Capacité</p>
                                <p class="font-medium text-text-primary">
                                    <?php if($trip->property_capacity): ?>
                                        <?php echo e($trip->property_capacity); ?> personnes max
                                    <?php else: ?>
                                        <?php echo e($trip->min_travelers); ?>-<?php echo e($trip->max_travelers); ?> personnes
                                    <?php endif; ?>
                                </p>
                            </div>
                            <?php if($trip->physical_level): ?>
                            <div>
                                <p class="text-sm text-text-secondary mb-1">Niveau physique</p>
                                <p class="font-medium text-text-primary">
                                    <?php switch($trip->physical_level):
                                        case ('easy'): ?>
                                            <span class="inline-flex items-center">
                                                <span class="h-2 w-2 bg-success rounded-full mr-2"></span>
                                                Facile
                                            </span>
                                            <?php break; ?>
                                        <?php case ('moderate'): ?>
                                            <span class="inline-flex items-center">
                                                <span class="h-2 w-2 bg-accent rounded-full mr-2"></span>
                                                Modéré
                                            </span>
                                            <?php break; ?>
                                        <?php case ('difficult'): ?>
                                            <span class="inline-flex items-center">
                                                <span class="h-2 w-2 bg-error rounded-full mr-2"></span>
                                                Difficile
                                            </span>
                                            <?php break; ?>
                                        <?php case ('extreme'): ?>
                                            <span class="inline-flex items-center">
                                                <span class="h-2 w-2 bg-error-dark rounded-full mr-2"></span>
                                                Extrême
                                            </span>
                                            <?php break; ?>
                                    <?php endswitch; ?>
                                </p>
                            </div>
                            <?php endif; ?>
                            <?php if($trip->meal_plan): ?>
                            <div>
                                <p class="text-sm text-text-secondary mb-1">Formule repas</p>
                                <p class="font-medium text-text-primary">
                                    <?php switch($trip->meal_plan):
                                        case ('none'): ?>
                                            Non inclus
                                            <?php break; ?>
                                        <?php case ('breakfast'): ?>
                                            Petit-déjeuner
                                            <?php break; ?>
                                        <?php case ('half_board'): ?>
                                            Demi-pension
                                            <?php break; ?>
                                        <?php case ('full_board'): ?>
                                            Pension complète
                                            <?php break; ?>
                                        <?php case ('all_inclusive'): ?>
                                            Tout inclus
                                            <?php break; ?>
                                    <?php endswitch; ?>
                                </p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Point de rendez-vous -->
                    <?php if($trip->meeting_point): ?>
                    <div>
                        <h4 class="text-sm font-medium text-text-secondary uppercase mb-3">Point de rendez-vous</h4>
                        <div class="p-4 bg-bg-alt rounded-lg">
                            <p class="font-medium text-text-primary"><?php echo e($trip->meeting_point); ?></p>
                            <?php if($trip->meeting_time): ?>
                            <p class="text-sm text-text-secondary mt-1">
                                Heure : <?php echo e(\Carbon\Carbon::parse($trip->meeting_time)->format('H:i')); ?>

                            </p>
                            <?php endif; ?>
                            <?php if($trip->meeting_address): ?>
                            <p class="text-sm text-text-secondary mt-1"><?php echo e($trip->meeting_address); ?></p>
                            <?php endif; ?>
                            <?php if($trip->meeting_instructions): ?>
                            <p class="text-sm text-text-secondary mt-2"><?php echo e($trip->meeting_instructions); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Inclus/Non inclus -->
                    <?php if(($trip->included && count($trip->included) > 0) || ($trip->not_included && count($trip->not_included) > 0)): ?>
                    <div>
                        <h4 class="text-sm font-medium text-text-secondary uppercase mb-3">Prestations</h4>
                        <div class="grid md:grid-cols-2 gap-6">
                            <?php if($trip->included && count($trip->included) > 0): ?>
                            <div>
                                <h5 class="font-medium text-text-primary mb-3 flex items-center">
                                    <svg class="h-5 w-5 text-success mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                    </svg>
                                    Inclus
                                </h5>
                                <ul class="space-y-2">
                                    <?php $__currentLoopData = $trip->included; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex items-start">
                                        <svg class="h-4 w-4 text-success mt-0.5 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                        </svg>
                                        <span class="text-sm text-text-secondary"><?php echo e($item); ?></span>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <?php if($trip->not_included && count($trip->not_included) > 0): ?>
                            <div>
                                <h5 class="font-medium text-text-primary mb-3 flex items-center">
                                    <svg class="h-5 w-5 text-error mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                    </svg>
                                    Non inclus
                                </h5>
                                <ul class="space-y-2">
                                    <?php $__currentLoopData = $trip->not_included; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex items-start">
                                        <svg class="h-4 w-4 text-error mt-0.5 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                        </svg>
                                        <span class="text-sm text-text-secondary"><?php echo e($item); ?></span>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Disponibilités -->
            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <div class="p-6 border-b border-border">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-text-primary">Prochaines disponibilités</h3>
                        <a href="<?php echo e(route('vendor.trips.availabilities.index', $trip)); ?>" 
                           class="text-sm text-primary hover:text-primary-dark font-medium">
                            Gérer toutes les dates →
                        </a>
                    </div>
                </div>
                <div class="p-6">
                    <?php if($trip->availabilities && $trip->availabilities->count() > 0): ?>
                        <div class="space-y-3">
                            <?php $__currentLoopData = $trip->availabilities->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-bg-alt/50 transition-colors">
                                <div class="flex-1">
                                    <div class="flex items-center">
                                        <p class="font-medium text-text-primary">
                                            <?php echo e($availability->start_date->format('d/m/Y')); ?> - <?php echo e($availability->end_date->format('d/m/Y')); ?>

                                        </p>
                                        <?php if($availability->is_guaranteed): ?>
                                            <span class="ml-2 px-2 py-0.5 text-xs font-medium rounded-full bg-success/15 text-success">
                                                Garanti
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex items-center mt-1 text-sm text-text-secondary">
                                        <span><?php echo e($availability->booked_spots); ?>/<?php echo e($availability->total_spots); ?> réservés</span>
                                        <?php if($availability->discount_percentage > 0): ?>
                                            <span class="ml-3 text-error font-medium">-<?php echo e($availability->discount_percentage); ?>%</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <p class="font-medium text-text-primary">
                                        <?php if($trip->pricing_mode === 'per_night_property' && $availability->property_price): ?>
                                            <?php echo e(number_format($availability->property_price, 0, ',', ' ')); ?> €/nuit
                                        <?php else: ?>
                                            <?php echo e(number_format($availability->adult_price, 0, ',', ' ')); ?> €/pers
                                        <?php endif; ?>
                                    </p>
                                    <p class="text-xs text-text-secondary mt-1">
                                        <?php echo e($availability->available_spots); ?> places restantes
                                    </p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-8">
                            <div class="h-16 w-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                                <svg class="h-8 w-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                </svg>
                            </div>
                            <p class="text-gray-500 font-medium">Aucune disponibilité</p>
                            <p class="text-sm text-gray-400 mt-1">Ajoutez des dates pour que votre offre soit réservable</p>
                            <a href="<?php echo e(route('vendor.trips.availabilities.create', $trip)); ?>" 
                               class="mt-4 inline-flex items-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors">
                                <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                                </svg>
                                Ajouter des disponibilités
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Colonne latérale -->
        <div class="space-y-6">
            <!-- Prix et informations clés -->
            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <div class="p-6">
                    <div class="text-center mb-6">
                        <p class="text-sm text-text-secondary">Prix de base</p>
                        <p class="text-3xl font-bold text-primary mt-1">
                            <?php echo e(number_format($trip->price, 0, ',', ' ')); ?> €
                        </p>
                        <p class="text-sm text-text-secondary mt-1">
                            <?php if($trip->pricing_mode === 'per_night_property'): ?>
                                par nuit
                            <?php elseif($trip->pricing_mode === 'per_person_per_day'): ?>
                                par personne par jour
                            <?php elseif($trip->pricing_mode === 'per_group'): ?>
                                par groupe
                            <?php else: ?>
                                par personne
                            <?php endif; ?>
                        </p>
                    </div>

                    <div class="space-y-3 pt-6 border-t border-border">
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-text-secondary">Type d'offre</span>
                            <span class="text-sm font-medium text-text-primary">
                                <?php if($trip->type === 'fixed'): ?>
                                    Séjour fixe
                                <?php elseif($trip->type === 'circuit'): ?>
                                    Circuit
                                <?php else: ?>
                                    <?php echo e(ucfirst($trip->type)); ?>

                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-text-secondary">Destination</span>
                            <span class="text-sm font-medium text-text-primary">
                                <?php if($trip->destination && is_object($trip->destination)): ?>
                                    <?php echo e($trip->destination->name); ?>

                                <?php else: ?>
                                    Non définie
                                <?php endif; ?>
                            </span>
                        </div>
                        <?php if($trip->travelType): ?>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-text-secondary">Catégorie</span>
                            <span class="text-sm font-medium text-text-primary">
                                <?php echo e($trip->travelType->name); ?>

                            </span>
                        </div>
                        <?php endif; ?>
                        <?php if($trip->languages && $trip->languages->count() > 0): ?>
                        <div class="flex justify-between items-start">
                            <span class="text-sm text-text-secondary">Langues</span>
                            <span class="text-sm font-medium text-text-primary text-right">
                                <?php echo e($trip->languages->pluck('name')->join(', ')); ?>

                            </span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Actions rapides -->
            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <div class="p-6">
                    <h4 class="font-medium text-text-primary mb-4">Actions rapides</h4>
                    <div class="space-y-2">
                        <a href="<?php echo e(route('trips.show', $trip->slug)); ?>" 
                           target="_blank"
                           class="w-full flex items-center justify-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors">
                            <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                            </svg>
                            Voir la page publique
                        </a>
                        <a href="<?php echo e(route('vendor.trips.availabilities.create', $trip)); ?>" 
                           class="w-full flex items-center justify-center px-4 py-2 bg-white border border-border text-text-primary rounded-lg hover:bg-bg-alt transition-colors">
                            <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                            </svg>
                            Ajouter une disponibilité
                        </a>
                        <button onclick="shareTrip()" 
                                class="w-full flex items-center justify-center px-4 py-2 bg-white border border-border text-text-primary rounded-lg hover:bg-bg-alt transition-colors">
                            <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/>
                            </svg>
                            Partager
                        </button>
                    </div>
                </div>
            </div>

            <!-- Conseils -->
            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <div class="p-6">
                    <h4 class="font-medium text-text-primary mb-4">Conseils pour améliorer votre offre</h4>
                    <div class="space-y-3">
                        <?php if(!$trip->images || count($trip->images) < 5): ?>
                        <div class="flex items-start">
                            <div class="flex-shrink-0 h-8 w-8 rounded-full bg-accent/10 flex items-center justify-center">
                                <svg class="h-4 w-4 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                </svg>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-text-primary">Ajoutez plus de photos</p>
                                <p class="text-xs text-text-secondary mt-1">Les offres avec 5+ photos ont 40% plus de réservations</p>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($tripStats['upcoming_availabilities'] < 5): ?>
                        <div class="flex items-start">
                            <div class="flex-shrink-0 h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                                <svg class="h-4 w-4 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                </svg>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-text-primary">Proposez plus de dates</p>
                                <p class="text-xs text-text-secondary mt-1">Ajoutez au moins 10 dates pour maximiser vos chances</p>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($trip->rating < 4 && $trip->reviews_count > 0): ?>
                        <div class="flex items-start">
                            <div class="flex-shrink-0 h-8 w-8 rounded-full bg-yellow-100 flex items-center justify-center">
                                <svg class="h-4 w-4 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/>
                                </svg>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-text-primary">Améliorez votre note</p>
                                <p class="text-xs text-text-secondary mt-1">Répondez aux avis pour montrer votre engagement</p>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal image -->
<div id="imageModal" class="fixed inset-0 z-50 hidden overflow-y-auto">
    <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true" onclick="closeImageModal()">
            <div class="absolute inset-0 bg-gray-900 opacity-90"></div>
        </div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full">
            <div class="bg-white">
                <div class="sm:flex sm:items-start">
                    <img id="modalImage" src="" alt="Image agrandie" class="w-full">
                </div>
            </div>
            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button type="button" onclick="closeImageModal()" 
                        class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                    Fermer
                </button>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function openImageModal(src) {
        document.getElementById('modalImage').src = src;
        document.getElementById('imageModal').classList.remove('hidden');
    }

    function closeImageModal() {
        document.getElementById('imageModal').classList.add('hidden');
    }

    function shareTrip() {
        const url = '<?php echo e(route('trips.show', $trip->slug)); ?>';
        if (navigator.share) {
            navigator.share({
                title: '<?php echo e($trip->title); ?>',
                text: '<?php echo e($trip->short_description); ?>',
                url: url
            });
        } else {
            // Fallback : copier dans le presse-papier
            navigator.clipboard.writeText(url).then(() => {
                alert('Lien copié dans le presse-papier !');
            });
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/trips/show.blade.php ENDPATH**/ ?>