

<?php $__env->startSection('title', $vendor->company_name . ' - Organisateur'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-bg-main min-h-screen">
    <!-- Hero Section comme destinations/show -->
    <div class="relative bg-gradient-to-r from-primary to-primary-dark text-white overflow-hidden">
        <div class="absolute inset-0">
            <div class="absolute inset-0 bg-black opacity-50 z-10"></div>
            <?php if($vendor->banner_image): ?>
            <img 
                src="<?php echo e(Storage::url($vendor->banner_image)); ?>" 
                alt="<?php echo e($vendor->company_name); ?>" 
                class="w-full h-full object-cover animate-slow-zoom"
            />
            <?php else: ?>
            <div class="w-full h-full bg-gradient-to-br from-primary to-primary-dark"></div>
            <?php endif; ?>
        </div>
        
        <div class="relative z-20 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
            <div class="max-w-3xl">
                <div class="flex flex-wrap items-center gap-2 mb-4">
                    <a href="<?php echo e(route('vendors.index')); ?>" class="inline-flex items-center text-white/80 hover:text-white text-sm font-medium transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                        </svg>
                        Organisateurs
                    </a>
                </div>
                
                <div class="flex items-center gap-4 mb-4">
                    <?php if($vendor->logo): ?>
                    <img src="<?php echo e(Storage::url($vendor->logo)); ?>" alt="<?php echo e($vendor->company_name); ?>" class="h-20 w-20 rounded-lg bg-white p-2">
                    <?php else: ?>
                    <div class="h-20 w-20 rounded-lg bg-white flex items-center justify-center">
                        <span class="text-2xl font-bold text-primary"><?php echo e($vendor->initials); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <div>
                        <h1 class="text-4xl md:text-5xl font-bold text-white">
                            <?php echo e($vendor->company_name); ?>

                        </h1>
                        
                        <div class="flex flex-wrap items-center gap-3 mt-2">
                            <?php if($vendor->isEmailVerified()): ?>
                            <span class="bg-white/20 text-white text-xs font-bold px-2 py-1 rounded">
                                ✓ Vérifié
                            </span>
                            <?php endif; ?>
                            
                            <?php if($subscriptionInfo['plan'] === 'pro'): ?>
                            <span class="bg-yellow-500/30 text-white text-xs font-bold px-2 py-1 rounded">
                                PRO
                            </span>
                            <?php elseif($subscriptionInfo['plan'] === 'essential'): ?>
                            <span class="bg-blue-500/30 text-white text-xs font-bold px-2 py-1 rounded">
                                ESSENTIAL
                            </span>
                            <?php endif; ?>
                            
                            <?php if($stats['average_rating'] > 0): ?>
                            <div class="flex items-center gap-1">
                                <div class="flex">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 <?php echo e($i <= $stats['average_rating'] ? 'text-yellow-400' : 'text-white/40'); ?>" viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                    <?php endfor; ?>
                                </div>
                                <span class="text-white/90"><?php echo e(number_format($stats['average_rating'], 1)); ?> (<?php echo e($stats['total_reviews']); ?> avis)</span>
                            </div>
                            <?php endif; ?>
                            
                            <span class="inline-flex items-center text-white/90">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                </svg>
                                <?php echo e($stats['total_trips']); ?> offres disponibles
                            </span>
                            
                            <span class="text-white/90">Membre depuis <?php echo e($stats['member_since']); ?></span>
                        </div>
                    </div>
                </div>
                
                <?php if($vendor->description): ?>
                <p class="mt-6 text-xl text-white/90">
                    <?php echo e(Str::limit($vendor->description, 200)); ?>

                </p>
                <?php endif; ?>
                
                <!-- CTA Buttons -->
                <div class="mt-8 flex flex-col sm:flex-row gap-4">
                    <a href="#offres" class="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-accent hover:bg-accent-dark focus:outline-none transition-colors">
                        Voir les offres
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </a>
                    <a href="#contact" class="inline-flex items-center justify-center px-6 py-3 border border-white text-base font-medium rounded-md shadow-sm text-white bg-transparent hover:bg-white/10 focus:outline-none transition-colors">
                        Contacter
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Vagues en bas du hero -->
        <div class="absolute bottom-0 left-0 right-0 z-10">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 140" class="w-full h-auto">
                <path 
                    fill="rgb(247, 250, 252)" 
                    fill-opacity="1" 
                    d="M0,96L48,90.7C96,85,192,75,288,80C384,85,480,107,576,106.7C672,107,768,85,864,74.7C960,64,1056,64,1152,69.3C1248,75,1344,85,1392,90.7L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
                />
            </svg>
        </div>
    </div>

    <!-- Contenu principal -->
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <!-- Colonne principale -->
            <div class="lg:col-span-2">
                <!-- À propos -->
                <?php if($vendor->description): ?>
                <div class="bg-white rounded-lg shadow-sm p-8 mb-10">
                    <h2 class="text-2xl font-bold text-text-primary mb-6">À propos de <?php echo e($vendor->company_name); ?></h2>
                    <div class="prose max-w-none text-text-secondary">
                        <?php echo nl2br(e($vendor->description)); ?>

                    </div>
                    <?php if($vendor->experience): ?>
                    <div class="mt-6 pt-6 border-t border-gray-200">
                        <h3 class="font-semibold text-text-primary mb-2">Expérience</h3>
                        <p class="text-text-secondary"><?php echo e($vendor->experience); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Offres disponibles avec filtres -->
                <div class="bg-white rounded-lg shadow-sm p-8 mb-10" id="offres">
                    <h2 class="text-2xl font-bold text-text-primary mb-6">Offres disponibles</h2>
                    
                    <?php if($trips && count($trips) > 0): ?>
                    <!-- Filtres par type -->
                    <div class="mb-6">
                        <div class="flex flex-wrap gap-2 mb-4">
                            <button 
                                data-filter="all"
                                class="filter-btn active px-4 py-2 rounded-full text-sm font-medium transition-colors bg-primary text-white"
                            >
                                Toutes les offres (<?php echo e($trips->total()); ?>)
                            </button>
                            <?php $__currentLoopData = $offerCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($type !== 'all' && $count > 0): ?>
                                <button 
                                    data-filter="<?php echo e($type); ?>"
                                    class="filter-btn px-4 py-2 rounded-full text-sm font-medium transition-colors bg-bg-alt text-text-secondary hover:bg-primary/10 hover:text-primary"
                                >
                                    <?php echo e(match($type) {
                                        'accommodation' => 'Hébergements',
                                        'organized_trip' => 'Séjours organisés',
                                        'activity' => 'Activités',
                                        'custom' => 'Sur mesure',
                                        default => ucfirst($type)
                                    }); ?> (<?php echo e($count); ?>)
                                </button>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    
                    <!-- Liste des offres -->
                    <div class="space-y-6">
                        <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div 
                            class="trip-item bg-bg-alt rounded-lg p-4 md:p-6 flex flex-col md:flex-row gap-4 hover:shadow-md transition-shadow"
                            data-offer-type="<?php echo e($trip->offer_type ?? 'organized_trip'); ?>"
                        >
                            <div class="md:w-1/3 h-48 rounded-lg overflow-hidden">
                                <?php if($trip->main_image): ?>
                                <img src="<?php echo e(Storage::url($trip->main_image)); ?>" alt="<?php echo e($trip->title); ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                <div class="w-full h-full bg-gray-200 flex items-center justify-center">
                                    <span class="text-gray-400">Image non disponible</span>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="md:w-2/3 flex flex-col justify-between">
                                <div>
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <h3 class="text-xl font-bold text-text-primary"><?php echo e($trip->title); ?></h3>
                                            <span class="inline-block mt-1 px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                                                <?php echo e($trip->offer_type_label ?? 'Séjour'); ?>

                                            </span>
                                        </div>
                                        <?php if($trip->rating > 0): ?>
                                        <div class="flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                            </svg>
                                            <span class="ml-1 text-sm font-bold text-text-primary"><?php echo e($trip->rating); ?></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <p class="mt-2 text-text-secondary line-clamp-3"><?php echo e($trip->short_description); ?></p>
                                    <div class="mt-3 flex flex-wrap gap-2">
                                        <?php if($trip->destination): ?>
                                        <span class="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full inline-flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                            </svg>
                                            <?php echo e($trip->destination->name); ?>

                                        </span>
                                        <?php endif; ?>
                                        <span class="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full inline-flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            <?php echo e($trip->duration_formatted ?? $trip->duration . ' jours'); ?>

                                        </span>
                                        <?php if($trip->availabilities && $trip->availabilities->count() > 0): ?>
                                        <span class="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                                            Disponible
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="flex justify-between items-end mt-4">
                                    <div class="text-right">
                                        <div class="text-text-secondary text-xs">à partir de</div>
                                        <div class="text-primary text-xl font-bold">
                                            <?php echo e(number_format($trip->price, 0, ',', ' ')); ?> €
                                            <?php if($trip->price_unit): ?>
                                            <span class="text-sm font-normal"><?php echo e($trip->price_unit); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <a href="<?php echo e(route('trips.show', $trip->slug ?? $trip->id)); ?>" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none transition-colors">
                                        Voir détails
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                    <?php if($trips->hasPages()): ?>
                    <div class="mt-8">
                        <?php echo e($trips->links()); ?>

                    </div>
                    <?php endif; ?>
                    
                    <?php else: ?>
                    <div class="text-center py-10 bg-bg-alt rounded-lg">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 mx-auto text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                        </svg>
                        <p class="text-text-secondary mt-4">Aucune offre disponible pour le moment</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Colonne latérale -->
            <div>
                <!-- Informations de contact -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6" id="contact">
                    <h2 class="text-xl font-bold text-text-primary mb-4">Informations de contact</h2>
                    <div class="space-y-4">
                        <?php if($vendor->phone): ?>
                        <div class="flex">
                            <div class="flex-shrink-0 h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                </svg>
                            </div>
                            <div class="ml-3">
                                <h3 class="text-sm font-medium text-text-primary">Téléphone</h3>
                                <p class="text-text-secondary"><?php echo e($vendor->phone); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($vendor->email): ?>
                        <div class="flex">
                            <div class="flex-shrink-0 h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                            </div>
                            <div class="ml-3">
                                <h3 class="text-sm font-medium text-text-primary">Email</h3>
                                <a href="mailto:<?php echo e($vendor->email); ?>" class="text-primary hover:text-primary-dark"><?php echo e($vendor->email); ?></a>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($vendor->website): ?>
                        <div class="flex">
                            <div class="flex-shrink-0 h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                                </svg>
                            </div>
                            <div class="ml-3">
                                <h3 class="text-sm font-medium text-text-primary">Site web</h3>
                                <a href="<?php echo e($vendor->website); ?>" target="_blank" class="text-primary hover:text-primary-dark">Visiter le site</a>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="flex">
                            <div class="flex-shrink-0 h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                </svg>
                            </div>
                            <div class="ml-3">
                                <h3 class="text-sm font-medium text-text-primary">Adresse</h3>
                                <p class="text-text-secondary">
                                    <?php echo e($vendor->address); ?><br>
                                    <?php echo e($vendor->postal_code); ?> <?php echo e($vendor->city); ?><br>
                                    <?php echo e($vendor->country); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-6">
                        <a href="mailto:<?php echo e($vendor->email); ?>" class="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none transition-colors">
                            Envoyer un message
                        </a>
                    </div>
                </div>

                <!-- Destinations principales -->
                <?php if($topDestinations && $topDestinations->count() > 0): ?>
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                    <h2 class="text-xl font-bold text-text-primary mb-4">Destinations principales</h2>
                    <div class="space-y-3">
                        <?php $__currentLoopData = $topDestinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('destinations.show', $destination->slug)); ?>" class="flex items-center justify-between p-2 rounded hover:bg-bg-alt transition-colors">
                            <span class="text-text-primary"><?php echo e($destination->name); ?></span>
                            <span class="text-xs text-text-secondary bg-bg-alt px-2 py-1 rounded">
                                <?php echo e($destination->trips_count); ?> offres
                            </span>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Informations légales -->
                <?php if($vendor->siret || $vendor->vat): ?>
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <h2 class="text-xl font-bold text-text-primary mb-4">Informations légales</h2>
                    <div class="space-y-2 text-sm">
                        <?php if($vendor->legal_status): ?>
                        <div class="flex justify-between">
                            <span class="text-text-secondary">Statut:</span>
                            <span class="text-text-primary font-medium"><?php echo e($vendor->legal_status); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if($vendor->siret): ?>
                        <div class="flex justify-between">
                            <span class="text-text-secondary">SIRET:</span>
                            <span class="text-text-primary font-medium"><?php echo e($vendor->siret); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if($vendor->vat): ?>
                        <div class="flex justify-between">
                            <span class="text-text-secondary">TVA:</span>
                            <span class="text-text-primary font-medium"><?php echo e($vendor->vat); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Filtres par type d'offre
    const filterButtons = document.querySelectorAll('.filter-btn');
    const tripItems = document.querySelectorAll('.trip-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Mise à jour des boutons actifs
            filterButtons.forEach(btn => {
                btn.classList.remove('bg-primary', 'text-white', 'active');
                btn.classList.add('bg-bg-alt', 'text-text-secondary');
            });
            this.classList.remove('bg-bg-alt', 'text-text-secondary');
            this.classList.add('bg-primary', 'text-white', 'active');
            
            // Filtrage des offres
            const filter = this.dataset.filter;
            tripItems.forEach(item => {
                if (filter === 'all' || item.dataset.offerType === filter) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
    
    // Smooth scroll pour les ancres
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetElement = document.querySelector(this.getAttribute('href'));
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Gestion de la pagination avec scroll
    const paginationLinks = document.querySelectorAll('.pagination a');
    paginationLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Le scroll vers #offres se fera automatiquement après le rechargement
            const url = new URL(this.href);
            url.hash = '#offres';
            this.href = url.toString();
        });
    });
    
    // Si on arrive depuis une pagination, scroll vers les offres
    if(window.location.hash === '#offres') {
        setTimeout(() => {
            document.getElementById('offres').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/show.blade.php ENDPATH**/ ?>