

<?php $__env->startSection('title', 'Paramètres'); ?>

<?php $__env->startSection('page-title', 'Paramètres'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Message de succès -->
    <?php if(session('success')): ?>
        <div class="bg-success/10 border border-success/20 rounded-lg p-4 flex items-center">
            <svg class="h-5 w-5 text-success mr-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p class="text-sm text-success font-medium"><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>

    <!-- Stats Cards comme dans admin -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Profil complété</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e($accountStats['profile_completion']); ?>%</p>
                </div>
                <div class="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Destinations</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e($accountStats['countries_count']); ?></p>
                </div>
                <div class="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Voyages actifs</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e($accountStats['total_trips']); ?></p>
                </div>
                <div class="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Plan actuel</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e(ucfirst($vendor->subscription_plan)); ?></p>
                </div>
                <div class="h-10 w-10 rounded-full bg-primary-dark/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-primary-dark" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <!-- Menu principal -->
    <div class="bg-white rounded-lg shadow-sm overflow-hidden">
        <div class="divide-y divide-border">
            <!-- Profil entreprise -->
            <a href="<?php echo e(route('vendor.settings.profile')); ?>" class="block hover:bg-bg-alt/30 transition-colors">
                <div class="p-6 flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                            <svg class="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-base font-medium text-text-primary">Profil entreprise</h3>
                            <p class="text-sm text-text-secondary">Informations générales et présentation de votre société</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <?php if($accountStats['profile_completion'] < 100): ?>
                            <span class="px-2 py-1 text-xs font-medium rounded-full bg-accent/15 text-accent mr-3">
                                À compléter
                            </span>
                        <?php endif; ?>
                        <svg class="h-5 w-5 text-text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                        </svg>
                    </div>
                </div>
            </a>

            <!-- Destinations & Services -->
            <a href="<?php echo e(route('vendor.settings.destinations')); ?>" class="block hover:bg-bg-alt/30 transition-colors">
                <div class="p-6 flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="h-12 w-12 rounded-lg bg-accent/10 flex items-center justify-center">
                            <svg class="h-6 w-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-base font-medium text-text-primary">Destinations & Services</h3>
                            <p class="text-sm text-text-secondary">Gérez vos zones géographiques et types de prestations</p>
                        </div>
                    </div>
                    <svg class="h-5 w-5 text-text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </div>
            </a>

            <!-- Compte & Sécurité -->
            <a href="<?php echo e(route('vendor.settings.security')); ?>" class="block hover:bg-bg-alt/30 transition-colors">
                <div class="p-6 flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="h-12 w-12 rounded-lg bg-success/10 flex items-center justify-center">
                            <svg class="h-6 w-6 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-base font-medium text-text-primary">Compte & Sécurité</h3>
                            <p class="text-sm text-text-secondary">Mot de passe, authentification et préférences de connexion</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <svg class="h-5 w-5 text-success mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <svg class="h-5 w-5 text-text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                        </svg>
                    </div>
                </div>
            </a>

            <!-- Abonnement & Facturation -->
            <a href="<?php echo e(route('vendor.settings.subscription')); ?>" class="block hover:bg-bg-alt/30 transition-colors">
                <div class="p-6 flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                            <svg class="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                            </svg>
                        </div>
                        <div class="ml-4 flex-1">
                            <h3 class="text-base font-medium text-text-primary">Abonnement & Facturation</h3>
                            <p class="text-sm text-text-secondary">Votre plan, moyens de paiement et factures</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <div class="text-right mr-3">
                            <p class="text-sm font-medium text-text-primary"><?php echo e(ucfirst($vendor->subscription_plan)); ?></p>
                            <p class="text-xs text-text-secondary"><?php echo e($accountStats['total_trips']); ?>/<?php echo e($vendor->max_trips == 9999 ? '∞' : $vendor->max_trips); ?> voyages</p>
                        </div>
                        <svg class="h-5 w-5 text-text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                        </svg>
                    </div>
                </div>
            </a>


        </div>
    </div>

    <!-- Autres actions -->
    <div class="bg-white rounded-lg shadow-sm overflow-hidden">
        <div class="p-6 border-b border-border">
            <h3 class="text-lg font-semibold text-text-primary">Autres actions</h3>
        </div>
        <div class="divide-y divide-border">
            <!-- Exporter données -->
            <a href="#" class="block hover:bg-bg-alt/30 transition-colors">
                <div class="p-6 flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="h-12 w-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                            <svg class="h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-base font-medium text-text-primary">Exporter mes données</h3>
                            <p class="text-sm text-text-secondary">Télécharger toutes vos informations</p>
                        </div>
                    </div>
                    <svg class="h-5 w-5 text-text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </div>
            </a>

            <!-- Factures -->
            <a href="#" class="block hover:bg-bg-alt/30 transition-colors">
                <div class="p-6 flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="h-12 w-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                            <svg class="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2zM10 8.5a.5.5 0 11-1 0 .5.5 0 011 0zm5 5a.5.5 0 11-1 0 .5.5 0 011 0z" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-base font-medium text-text-primary">Mes factures</h3>
                            <p class="text-sm text-text-secondary">Consulter et télécharger vos factures</p>
                        </div>
                    </div>
                    <svg class="h-5 w-5 text-text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </div>
            </a>

            <!-- Support -->
            <a href="mailto:support@marketplace.com" class="block hover:bg-bg-alt/30 transition-colors">
                <div class="p-6 flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="h-12 w-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                            <svg class="h-6 w-6 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-base font-medium text-text-primary">Contacter le support</h3>
                            <p class="text-sm text-text-secondary">Assistance technique et commerciale</p>
                        </div>
                    </div>
                    <svg class="h-5 w-5 text-text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </div>
            </a>

            <!-- Centre d'aide -->
            <a href="#" class="block hover:bg-bg-alt/30 transition-colors">
                <div class="p-6 flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="h-12 w-12 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                            <svg class="h-6 w-6 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-base font-medium text-text-primary">Centre d'aide</h3>
                            <p class="text-sm text-text-secondary">Documentation et guides</p>
                        </div>
                    </div>
                    <svg class="h-5 w-5 text-text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </div>
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/settings/index.blade.php ENDPATH**/ ?>