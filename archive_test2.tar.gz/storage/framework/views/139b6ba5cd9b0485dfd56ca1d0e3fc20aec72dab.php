

<?php $__env->startSection('title', 'Messages archivés'); ?>
<?php $__env->startSection('page-title', 'Messages archivés'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-4 lg:space-y-6">
    <div class="w-full">
        <div class="bg-white rounded-lg shadow-sm">
            <!-- Header -->
            <div class="p-4 border-b border-gray-200">
                <div class="flex items-center justify-between">
                    <h3 class="font-semibold text-gray-900">Conversations archivées</h3>
                    <a href="<?php echo e(route('vendor.messages.index')); ?>" 
                       class="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors">
                        ← Retour aux messages
                    </a>
                </div>
            </div>

            <!-- Liste des conversations archivées -->
            <div class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $otherUser = $conversation->sender_id == Auth::id() 
                            ? $conversation->recipient
                            : $conversation->sender;
                        \Carbon\Carbon::setLocale('fr');
                    ?>
                    
                    <div class="group relative hover:bg-gray-50 transition-all">
                        <a href="<?php echo e(route('vendor.messages.show', $conversation->trip->slug ?? $conversation->conversation_id)); ?>"
                           class="block p-4 sm:p-6">
                            <div class="flex items-start gap-3 sm:gap-4">
                                <!-- Avatar -->
                                <div class="flex-shrink-0">
                                    <?php if($otherUser && $otherUser->avatar): ?>
                                        <img src="<?php echo e(Storage::url($otherUser->avatar)); ?>" 
                                             alt="<?php echo e($otherUser->name); ?>"
                                             class="h-10 w-10 sm:h-12 sm:w-12 rounded-full object-cover">
                                    <?php else: ?>
                                        <div class="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center">
                                            <span class="text-sm sm:text-base font-medium text-white">
                                                <?php echo e(strtoupper(substr($otherUser->name ?? 'U', 0, 1))); ?>

                                            </span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Contenu principal -->
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-start justify-between gap-2">
                                        <div class="flex-1 min-w-0">
                                            <!-- Nom et voyage -->
                                            <div class="flex flex-col sm:flex-row sm:items-center sm:gap-3">
                                                <p class="font-medium text-gray-900">
                                                    <?php echo e($otherUser->name ?? 'Utilisateur'); ?>

                                                </p>
                                                <?php if($conversation->trip): ?>
                                                    <p class="text-xs sm:text-sm text-primary font-medium truncate">
                                                        <?php echo e($conversation->trip->title); ?>

                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <!-- Message preview -->
                                            <p class="mt-1 text-sm text-gray-600 line-clamp-2 sm:line-clamp-1">
                                                <?php if($conversation->sender_id == Auth::id()): ?>
                                                    <span class="text-gray-400">Vous: </span>
                                                <?php endif; ?>
                                                <?php echo e($conversation->content); ?>

                                            </p>
                                        </div>
                                        
                                        <!-- Actions et heure -->
                                        <div class="flex flex-col items-end gap-2">
                                            <p class="text-xs text-gray-500 whitespace-nowrap">
                                                <?php echo e($conversation->created_at->diffForHumans()); ?>

                                            </p>
                                            
                                            <!-- Bouton restaurer -->
                                            <form action="<?php echo e(route('vendor.messages.unarchive', $conversation->trip->slug ?? $conversation->conversation_id)); ?>" 
                                                  method="POST" 
                                                  onclick="event.stopPropagation();">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" 
                                                        class="px-3 py-1 bg-success text-white text-xs rounded hover:bg-success-dark transition-colors">
                                                    Restaurer
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- État vide -->
                    <div class="flex flex-col items-center justify-center py-12 px-4">
                        <div class="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                      d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/>
                            </svg>
                        </div>
                        <p class="text-gray-900 font-medium mb-1">Aucune conversation archivée</p>
                        <p class="text-sm text-gray-500 text-center">Les conversations archivées apparaîtront ici</p>
                        <a href="<?php echo e(route('vendor.messages.index')); ?>" 
                           class="mt-4 text-sm text-primary hover:text-primary-dark">
                            ← Voir toutes les conversations
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.line-clamp-1 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
}
.line-clamp-2 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/messages/archived.blade.php ENDPATH**/ ?>