

<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('page-title', 'Messages'); ?>
<?php $__env->startSection('page-description', 'Gérez vos conversations avec les clients'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-4 lg:space-y-6">
    <!-- Liste des conversations - Pleine largeur -->
    <div class="w-full">
        <div class="bg-white rounded-lg shadow-sm">
            <!-- Header avec compteur -->
            <div class="p-4 border-b border-gray-200">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div class="flex items-center justify-between">
                        <h3 class="font-semibold text-gray-900">Conversations</h3>
                        <?php if($unreadCount > 0): ?>
                            <span class="sm:hidden inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                <?php echo e($unreadCount); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Barre de recherche et badges - responsive -->
                    <div class="flex flex-col sm:flex-row sm:items-center gap-3 flex-1 sm:max-w-lg">
                        <form action="<?php echo e(route('vendor.messages.search')); ?>" method="GET" class="flex-1">
                            <div class="relative">
                                <svg class="absolute left-3 top-2.5 h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                                </svg>
                                <input type="text" 
                                       name="q" 
                                       placeholder="Rechercher..." 
                                       value="<?php echo e($query ?? ''); ?>"
                                       class="w-full pl-9 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary">
                            </div>
                        </form>
                        
                        <?php if($unreadCount > 0): ?>
                            <span class="hidden sm:inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-red-100 text-red-800 whitespace-nowrap">
                                <?php echo e($unreadCount); ?> non lu<?php echo e($unreadCount > 1 ? 's' : ''); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if(isset($query) && $query): ?>
                    <a href="<?php echo e(route('vendor.messages.index')); ?>" class="text-xs text-gray-500 hover:text-gray-700 mt-2 inline-block">
                        ← Effacer la recherche
                    </a>
                <?php endif; ?>
            </div>

            <!-- Tabs de filtrage - scrollable sur mobile -->
            <div class="border-b border-gray-200">
                <div class="px-4 overflow-x-auto">
                    <nav class="-mb-px flex space-x-6 min-w-max">
                        <a href="<?php echo e(route('vendor.messages.index')); ?>" 
                           class="py-3 px-1 border-b-2 font-medium text-sm transition-colors whitespace-nowrap
                                  <?php echo e(!isset($filter) || $filter == 'all' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                            Tous
                        </a>
                        <a href="<?php echo e(route('vendor.messages.unread')); ?>" 
                           class="py-3 px-1 border-b-2 font-medium text-sm transition-colors whitespace-nowrap
                                  <?php echo e(isset($filter) && $filter == 'unread' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                            Non lus
                            <?php if($unreadCount > 0): ?>
                                <span class="ml-1 text-xs text-gray-400">(<?php echo e($unreadCount); ?>)</span>
                            <?php endif; ?>
                        </a>
                        <a href="<?php echo e(route('vendor.messages.archived')); ?>" 
                           class="py-3 px-1 border-b-2 font-medium text-sm transition-colors whitespace-nowrap
                                  <?php echo e(isset($filter) && $filter == 'archived' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                            Archivés
                        </a>
                    </nav>
                </div>
            </div>

            <!-- Liste des conversations - Grid responsive -->
            <div class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $otherUser = $conversation->getOtherParticipant(Auth::id());
                        $isUnread = !$conversation->is_read && $conversation->recipient_id == Auth::id();
                        
                        // Configuration locale FR pour Carbon
                        \Carbon\Carbon::setLocale('fr');
                    ?>
                    
                    <div class="group relative hover:bg-gray-50 transition-all
                                <?php echo e($isUnread ? 'bg-blue-50 border-l-4 border-l-primary' : ''); ?>">
                        <a href="<?php echo e(route('vendor.messages.show', $conversation->trip->slug ?? 'default')); ?>"
                           class="block p-4 sm:p-6">
                            <div class="flex items-start gap-3 sm:gap-4">
                                <!-- Avatar -->
                                <div class="flex-shrink-0">
                                    <?php if($otherUser && $otherUser->avatar): ?>
                                        <img src="<?php echo e(Storage::url($otherUser->avatar)); ?>" 
                                             alt="<?php echo e($otherUser->name); ?>"
                                             class="h-10 w-10 sm:h-12 sm:w-12 rounded-full object-cover">
                                    <?php else: ?>
                                        <div class="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center">
                                            <span class="text-sm sm:text-base font-medium text-white">
                                                <?php echo e(strtoupper(substr($otherUser->name ?? 'U', 0, 1))); ?>

                                            </span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Contenu principal -->
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-start justify-between gap-2">
                                        <div class="flex-1 min-w-0">
                                            <!-- Nom et voyage -->
                                            <div class="flex flex-col sm:flex-row sm:items-center sm:gap-3">
                                                <p class="font-medium text-gray-900 <?php echo e($isUnread ? 'font-semibold' : ''); ?>">
                                                    <?php echo e($otherUser->name ?? 'Utilisateur'); ?>

                                                </p>
                                                <?php if($conversation->trip): ?>
                                                    <p class="text-xs sm:text-sm text-primary font-medium truncate">
                                                        <?php echo e($conversation->trip->title); ?>

                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <!-- Message preview -->
                                            <p class="mt-1 text-sm text-gray-600 line-clamp-2 sm:line-clamp-1">
                                                <?php if($conversation->sender_id == Auth::id()): ?>
                                                    <span class="text-gray-400">Vous: </span>
                                                <?php endif; ?>
                                                <?php echo e($conversation->content); ?>

                                            </p>
                                        </div>
                                        
                                        <!-- Actions et heure -->
                                        <div class="flex flex-col items-end gap-1 ml-2">
                                            <div class="flex items-center gap-2">
                                                <!-- Version Desktop: archivage au survol -->
                                                <div class="hidden lg:block">
                                                    <!-- Heure normale, cachée au survol du groupe -->
                                                    <p class="text-xs text-gray-500 whitespace-nowrap group-hover:hidden">
                                                        <?php echo e($conversation->created_at->diffForHumans()); ?>

                                                    </p>
                                                    
                                                    <!-- Bouton archiver avec tooltip, visible seulement au survol -->
                                                    <div class="hidden group-hover:flex items-center relative">
                                                        <form action="<?php echo e(route('vendor.messages.archive', $conversation->trip->slug ?? 'default')); ?>" 
                                                              method="POST" 
                                                              onclick="event.stopPropagation();">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" 
                                                                    title="Archiver"
                                                                    class="p-1 text-gray-400 hover:text-amber-600 transition-colors group/btn">
                                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                                          d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/>
                                                                </svg>
                                                                
                                                                <!-- Tooltip qui apparaît au survol du bouton -->
                                                                <span class="absolute right-full mr-2 top-1/2 -translate-y-1/2 
                                                                           px-2 py-1 text-xs text-white rounded 
                                                                           whitespace-nowrap opacity-0 group-hover/btn:opacity-100 
                                                                           transition-opacity pointer-events-none"
                                                                      style="background-color: #35a29e;">
                                                                    Archiver la conversation
                                                                </span>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                                
                                                <!-- Version Mobile: menu trois points -->
                                                <div class="lg:hidden relative" onclick="event.stopPropagation();">
                                                    <button type="button" 
                                                            class="p-1 rounded hover:bg-gray-200 transition-colors action-menu-btn"
                                                            data-conversation-id="<?php echo e($conversation->id); ?>">
                                                        <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                                                            <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z"/>
                                                        </svg>
                                                    </button>
                                                    
                                                    <!-- Menu dropdown mobile -->
                                                    <div class="hidden absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg border border-gray-200 z-10 action-menu"
                                                         data-conversation-id="<?php echo e($conversation->id); ?>">
                                                        <?php if($isUnread): ?>
                                                            <form action="<?php echo e(route('vendor.messages.markAsRead', $conversation->trip->slug ?? 'default')); ?>" 
                                                                  method="POST" 
                                                                  class="block">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" 
                                                                        class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                                    Marquer comme lu
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                        
                                                        <form action="<?php echo e(route('vendor.messages.archive', $conversation->trip->slug ?? 'default')); ?>" 
                                                              method="POST" 
                                                              class="block">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" 
                                                                    class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                                Archiver
                                                            </button>
                                                        </form>
                                                        
                                                        <form action="<?php echo e(route('vendor.messages.delete', $conversation->trip->slug ?? 'default')); ?>" 
                                                              method="POST" 
                                                              class="block"
                                                              onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette conversation ?');">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" 
                                                                    class="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                                                                Supprimer
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                                
                                                <!-- Heure sur mobile seulement -->
                                                <p class="lg:hidden text-xs text-gray-500 whitespace-nowrap">
                                                    <?php echo e($conversation->created_at->diffForHumans()); ?>

                                                </p>
                                            </div>
                                            
                                            <!-- Badge nombre non lus -->
                                            <?php if(isset($conversation->unread_count) && $conversation->unread_count > 0): ?>
                                                <span class="inline-flex items-center justify-center min-w-[20px] h-5 px-1 text-xs font-bold text-white bg-primary rounded-full">
                                                    <?php echo e($conversation->unread_count); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- État vide -->
                    <div class="flex flex-col items-center justify-center py-12 px-4">
                        <div class="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                      d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                            </svg>
                        </div>
                        
                        <?php if(isset($filter)): ?>
                            <?php switch($filter):
                                case ('unread'): ?>
                                    <p class="text-gray-900 font-medium mb-1">Aucun message non lu</p>
                                    <p class="text-sm text-gray-500 text-center">Tous vos messages ont été lus</p>
                                    <?php break; ?>
                                <?php case ('archived'): ?>
                                    <p class="text-gray-900 font-medium mb-1">Aucune conversation archivée</p>
                                    <p class="text-sm text-gray-500 text-center">Les conversations archivées apparaîtront ici</p>
                                    <?php break; ?>
                                <?php case ('search'): ?>
                                    <p class="text-gray-900 font-medium mb-1">Aucun résultat</p>
                                    <p class="text-sm text-gray-500 text-center">Essayez avec d'autres mots-clés</p>
                                    <?php break; ?>
                            <?php endswitch; ?>
                            <a href="<?php echo e(route('vendor.messages.index')); ?>" 
                               class="mt-3 text-sm text-primary hover:text-primary-dark">
                                ← Voir toutes les conversations
                            </a>
                        <?php else: ?>
                            <p class="text-gray-900 font-medium mb-1">Aucune conversation</p>
                            <p class="text-sm text-gray-500 text-center">Les messages de vos clients apparaîtront ici</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Footer avec action -->
            <?php if($conversations->count() > 0 && $unreadCount > 0): ?>
                <div class="p-4 border-t border-gray-200 bg-gray-50">
                    <form action="<?php echo e(route('vendor.messages.markAllAsRead')); ?>" method="POST" class="text-center">
                        <?php echo csrf_field(); ?>
                        <button type="submit" 
                                class="text-sm text-gray-600 hover:text-primary inline-flex items-center">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            Tout marquer comme lu
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* Limite le nombre de lignes affichées */
.line-clamp-1 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
}
.line-clamp-2 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Gestion du menu d'actions
document.addEventListener('DOMContentLoaded', function() {
    // Toggle menu au clic (pour mobile)
    document.querySelectorAll('.action-menu-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const conversationId = this.dataset.conversationId;
            const menu = document.querySelector(`.action-menu[data-conversation-id="${conversationId}"]`);
            
            // Fermer tous les autres menus
            document.querySelectorAll('.action-menu').forEach(m => {
                if (m !== menu) m.classList.add('hidden');
            });
            
            // Toggle ce menu
            menu.classList.toggle('hidden');
        });
    });
    
    // Fermer les menus au clic ailleurs
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.action-menu-btn') && !e.target.closest('.action-menu')) {
            document.querySelectorAll('.action-menu').forEach(menu => {
                menu.classList.add('hidden');
            });
        }
    });
    
    // Empêcher la propagation du clic sur les formulaires
    document.querySelectorAll('.action-menu form').forEach(form => {
        form.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/messages/index.blade.php ENDPATH**/ ?>