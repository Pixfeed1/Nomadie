

<?php $__env->startSection('title', 'Conversation'); ?>

<?php $__env->startSection('page-title', 'Messages'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Partie info client -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="flex items-center justify-between mb-4">
            <a href="<?php echo e(route('vendor.messages.index')); ?>" class="flex items-center text-gray-600 hover:text-primary transition-colors">
                <svg class="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                </svg>
                Retour aux messages
            </a>
            
            <!-- Bouton archiver/désarchiver avec style cohérent -->
            <?php if($isArchived): ?>
                <form action="<?php echo e(route('vendor.messages.unarchive', $tripSlug ?? $conversationId)); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="px-4 py-2 bg-success text-white rounded-lg hover:bg-success-dark transition-colors flex items-center">
                        <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        Désarchiver
                    </button>
                </form>
            <?php else: ?>
                <form action="<?php echo e(route('vendor.messages.archive', $tripSlug ?? $conversationId)); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors flex items-center">
                        <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/>
                        </svg>
                        Archiver
                    </button>
                </form>
            <?php endif; ?>
        </div>
        
        <!-- Reste du contenu inchangé -->
        <div class="flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <!-- Avatar et info client -->
                <div class="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center">
                    <?php if($otherParticipant->avatar): ?>
                        <img src="<?php echo e(Storage::url($otherParticipant->avatar)); ?>" class="h-12 w-12 rounded-full object-cover">
                    <?php else: ?>
                        <span class="text-lg font-bold text-gray-600">
                            <?php echo e(strtoupper(substr($otherParticipant->name, 0, 2))); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <div>
                    <p class="font-medium text-gray-900"><?php echo e($otherParticipant->name); ?></p>
                    <p class="text-xs text-gray-500">Client depuis <?php echo e($otherParticipant->created_at->format('M Y')); ?></p>
                </div>
            </div>
            
            <!-- Info sur l'offre à droite -->
            <?php if($trip): ?>
            <div class="p-3 bg-gray-50 rounded-lg max-w-xs">
                <p class="text-xs text-gray-500 mb-1">Concernant :</p>
                <p class="font-medium text-sm text-gray-900 truncate"><?php echo e($trip->title); ?></p>
                <a href="<?php echo e(route('vendor.trips.show', $trip)); ?>" class="text-xs text-primary hover:underline mt-1 inline-block">
                    Voir l'offre →
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Zone de conversation - reste inchangé -->
    <div class="bg-white rounded-lg shadow-sm flex flex-col" style="height: 500px;">
        <!-- Messages -->
        <div class="flex-1 overflow-y-auto p-6 space-y-4" id="messages-container">
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex <?php echo e($message->sender_id == Auth::id() ? 'justify-end' : 'justify-start'); ?>">
                    <?php if($message->sender_id != Auth::id()): ?>
                        <!-- Avatar client à gauche -->
                        <div class="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center mr-2">
                            <?php if($message->sender->avatar): ?>
                                <img src="<?php echo e(Storage::url($message->sender->avatar)); ?>" class="h-8 w-8 rounded-full object-cover">
                            <?php else: ?>
                                <span class="text-xs font-bold text-gray-600">
                                    <?php echo e(strtoupper(substr($message->sender->name, 0, 2))); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="max-w-xs lg:max-w-md">
                        <div class="text-gray-900 px-4 py-2">
                            <p class="text-sm"><?php echo e($message->content); ?></p>
                            
                            <!-- Si pièce jointe -->
                            <?php if($message->attachment): ?>
                                <div class="mt-2 p-2 bg-gray-50 rounded-lg">
                                    <a href="<?php echo e(route('vendor.messages.download', $message->id)); ?>" 
                                       class="flex items-center space-x-2 text-primary hover:text-primary-dark">
                                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/>
                                        </svg>
                                        <span class="text-xs truncate max-w-[150px]"><?php echo e($message->attachment_name ?? 'Pièce jointe'); ?></span>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                        <p class="text-xs text-gray-500 mt-1 <?php echo e($message->sender_id == Auth::id() ? 'text-right' : ''); ?>">
                            <?php echo e($message->created_at->format('H:i')); ?>

                            <?php if($message->sender_id == Auth::id() && $message->is_read): ?>
                                <span class="text-primary ml-1">✓✓</span>
                            <?php elseif($message->sender_id == Auth::id()): ?>
                                <span class="text-gray-400 ml-1">✓</span>
                            <?php endif; ?>
                        </p>
                    </div>
                    
                    <?php if($message->sender_id == Auth::id()): ?>
                        <!-- Logo vendor à droite -->
                        <div class="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center ml-2">
                            <?php
                                $vendor = Auth::user()->vendor;
                            ?>
                            <?php if($vendor && $vendor->logo): ?>
                                <img src="<?php echo e(Storage::url($vendor->logo)); ?>" class="h-8 w-8 rounded-full object-cover">
                            <?php else: ?>
                                <span class="text-xs font-bold text-gray-600">
                                    <?php echo e(strtoupper(substr($vendor ? $vendor->company_name : 'V', 0, 2))); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Zone de saisie avec pièces jointes -->
        <div class="p-4 border-t border-gray-200">
            <form action="<?php echo e(route('vendor.messages.reply', $tripSlug ?? $conversationId)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="flex items-end space-x-2">
                    <!-- Bouton pièce jointe -->
                    <label for="attachment" class="cursor-pointer text-gray-500 hover:text-gray-700 mb-2">
                        <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/>
                        </svg>
                        <input type="file" 
                               id="attachment" 
                               name="attachment" 
                               class="hidden"
                               accept=".pdf,.jpg,.jpeg,.png"
                               max="5242880"
                               onchange="showFileName(this)">
                    </label>
                    
                    <!-- Champ de texte -->
                    <div class="flex-1">
                        <input type="text" 
                               name="content"
                               placeholder="Écrivez votre message..."
                               class="w-full px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                               required>
                        <span id="file-name" class="text-xs text-gray-500 mt-1 hidden"></span>
                    </div>
                    
                    <!-- Bouton envoyer -->
                    <button type="submit" 
                            class="p-2 bg-primary text-white rounded-full hover:bg-primary-dark">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
                        </svg>
                    </button>
                </div>
                
                <!-- Info sur les pièces jointes -->
                <p class="text-xs text-gray-500 mt-2">
                    Fichiers acceptés : PDF, Images (max 5MB)
                </p>
            </form>
        </div>
    </div>
</div>

<script>
// Auto-scroll vers le bas
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('messages-container');
    container.scrollTop = container.scrollHeight;
});

// Afficher le nom du fichier sélectionné avec vérification de taille
function showFileName(input) {
    if (input.files[0]) {
        const file = input.files[0];
        const maxSize = 5 * 1024 * 1024; // 5MB
        
        if (file.size > maxSize) {
            alert('Le fichier est trop gros. Maximum 5MB.');
            input.value = '';
            return;
        }
        
        const fileNameSpan = document.getElementById('file-name');
        fileNameSpan.textContent = 'Fichier : ' + file.name;
        fileNameSpan.classList.remove('hidden');
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/messages/show.blade.php ENDPATH**/ ?>