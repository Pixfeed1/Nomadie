

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="dashboardData" class="space-y-6">
    <!-- En-tête avec actions -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between space-y-3 md:space-y-0 md:space-x-4">
        <div>
            <h2 class="text-xl font-bold text-text-primary">Tableau de bord</h2>
            <p class="text-sm text-text-secondary mt-1">Gérez vos offres et suivez votre activité</p>
        </div>
        
        <div class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
            <?php if($stats['can_create_trips']): ?>
                <a href="<?php echo e(route('vendor.trips.select-type')); ?>" class="flex items-center justify-center px-4 py-2 bg-primary hover:bg-primary-dark text-white font-medium rounded-lg transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    Créer une offre
                </a>
            <?php endif; ?>
            
            <a href="<?php echo e(route('vendor.dashboard.analytics')); ?>" class="flex items-center justify-center px-4 py-2 bg-white border border-border text-text-primary hover:bg-bg-alt font-medium rounded-lg transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
                Voir les analytics
            </a>
        </div>
    </div>

    <!-- Statistiques rapides -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- Offres actives -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Offres actives</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e($stats['active_trips']); ?></p>
                    <p class="text-xs text-text-secondary mt-1">
                        Sur <?php echo e($stats['max_trips'] == 9999 ? '∞' : $stats['max_trips']); ?> max
                    </p>
                </div>
                <div class="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
            </div>
        </div>
        
        <!-- Réservations -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Réservations</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e($stats['total_bookings']); ?></p>
                    <p class="text-xs text-success mt-1 flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                        </svg>
                        +15% ce mois
                    </p>
                </div>
                <div class="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                    </svg>
                </div>
            </div>
        </div>
        
        <!-- Revenus -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Revenus totaux</p>
                    <p class="text-2xl font-bold text-text-primary mt-1"><?php echo e(number_format($stats['total_revenue'], 0, ',', ' ')); ?> €</p>
                    <p class="text-xs text-text-secondary mt-1">Commission: <?php echo e($stats['commission_rate']); ?>%</p>
                </div>
                <div class="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
            </div>
        </div>
        
        <!-- Note moyenne -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-4 flex items-center justify-between">
                <div>
                    <p class="text-text-secondary text-xs font-medium uppercase">Note moyenne</p>
                    <p class="text-2xl font-bold text-text-primary mt-1">
                        <?php if($stats['avg_rating'] > 0): ?>
                            <?php echo e($stats['avg_rating']); ?>/5
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </p>
                    <div class="flex items-center mt-1">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <svg class="h-3 w-3 <?php echo e($i <= $stats['avg_rating'] ? 'text-yellow-400' : 'text-gray-300'); ?>" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                            </svg>
                        <?php endfor; ?>
                    </div>
                </div>
                <div class="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                    </svg>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Graphiques et tableaux -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Graphique des revenus -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden lg:col-span-2 card">
            <div class="p-6 border-b border-border">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-text-primary">Évolution des revenus</h3>
                    <select class="border border-border rounded-md text-sm py-1 px-2 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary">
                        <option>6 derniers mois</option>
                        <option>Cette année</option>
                        <option>Année précédente</option>
                    </select>
                </div>
            </div>
            <div class="p-6">
                <div class="h-72">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Offres les plus populaires -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden card">
            <div class="p-6 border-b border-border">
                <h3 class="text-lg font-semibold text-text-primary">Offres les plus réservées</h3>
                <p class="text-sm text-text-secondary mt-1">Ce mois-ci</p>
            </div>
            <div class="p-6">
                <div class="space-y-4">
                    <?php $__empty_1 = true; $__currentLoopData = $recentTrips->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center">
                            <div class="flex-shrink-0 h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                                <?php echo e(substr($trip->title, 0, 2)); ?>

                            </div>
                            <div class="ml-3 flex-1">
                                <div class="flex items-center justify-between">
                                    <p class="text-sm font-medium text-text-primary truncate"><?php echo e($trip->title); ?></p>
                                    <p class="text-sm font-medium text-text-primary">
                                        <?php if($trip->pricing_mode == 'per_night_property'): ?>
                                            <?php echo e(number_format($trip->price, 0, ',', ' ')); ?> €/nuit
                                        <?php elseif($trip->pricing_mode == 'per_person_activity'): ?>
                                            <?php echo e(number_format($trip->price, 0, ',', ' ')); ?> €/pers
                                        <?php else: ?>
                                            <?php echo e(number_format($trip->price, 0, ',', ' ')); ?> €
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div class="flex items-center justify-between mt-1">
                                    <p class="text-xs text-text-secondary"><?php echo e($trip->destination->name ?? 'N/A'); ?></p>
                                    <div class="flex items-center text-xs text-success">
                                        <svg class="h-3 w-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                                        </svg>
                                        <?php echo e(rand(5, 20)); ?> ventes
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-4">
                            <p class="text-sm text-text-secondary">Aucune offre créée</p>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if($recentTrips->count() > 5): ?>
                    <div class="mt-6 pt-4 border-t border-border">
                        <a href="<?php echo e(route('vendor.trips.index')); ?>" class="text-sm text-primary hover:text-primary-dark font-medium flex items-center justify-center">
                            Voir toutes les offres
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                            </svg>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Actions rapides et Statut abonnement -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Actions rapides -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden card">
            <div class="p-6 border-b border-border">
                <h3 class="text-lg font-semibold text-text-primary">Actions rapides</h3>
                <p class="text-sm text-text-secondary mt-1">Accès rapide aux fonctionnalités principales</p>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-2 gap-4">
                    <?php if($stats['can_create_trips']): ?>
                        <a href="<?php echo e(route('vendor.trips.select-type')); ?>" class="flex flex-col items-center p-4 rounded-lg border border-border hover:bg-bg-alt/50 hover:border-primary transition-all group">
                            <div class="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                </svg>
                            </div>
                            <span class="text-sm font-medium text-text-primary text-center">Créer une offre</span>
                        </a>
                    <?php else: ?>
                        <div class="flex flex-col items-center p-4 rounded-lg border border-border bg-bg-alt/50 cursor-not-allowed opacity-50">
                            <div class="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center mb-3">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                </svg>
                            </div>
                            <span class="text-sm font-medium text-text-secondary text-center">Limite atteinte</span>
                        </div>
                    <?php endif; ?>
                    
                    <a href="<?php echo e(route('vendor.trips.index')); ?>" class="flex flex-col items-center p-4 rounded-lg border border-border hover:bg-bg-alt/50 hover:border-accent transition-all group">
                        <div class="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center mb-3 group-hover:bg-accent/20 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                            </svg>
                        </div>
                        <span class="text-sm font-medium text-text-primary text-center">Mes offres</span>
                    </a>
                    
                    <a href="<?php echo e(route('vendor.dashboard.analytics')); ?>" class="flex flex-col items-center p-4 rounded-lg border border-border hover:bg-bg-alt/50 hover:border-success transition-all group">
                        <div class="h-12 w-12 rounded-full bg-success/10 flex items-center justify-center mb-3 group-hover:bg-success/20 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                            </svg>
                        </div>
                        <span class="text-sm font-medium text-text-primary text-center">Analytics</span>
                    </a>
                    
                    <a href="<?php echo e(route('vendor.settings.index')); ?>" class="flex flex-col items-center p-4 rounded-lg border border-border hover:bg-bg-alt/50 hover:border-primary-dark transition-all group">
                        <div class="h-12 w-12 rounded-full bg-primary-dark/10 flex items-center justify-center mb-3 group-hover:bg-primary-dark/20 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary-dark" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                        </div>
                        <span class="text-sm font-medium text-text-primary text-center">Paramètres</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Statut de l'abonnement -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden card">
            <div class="p-6 border-b border-border">
                <h3 class="text-lg font-semibold text-text-primary">Votre abonnement</h3>
                <p class="text-sm text-text-secondary mt-1"><?php echo e(ucfirst($stats['subscription_info']['plan_name'])); ?></p>
            </div>
            
            <div class="p-6">
                <div class="space-y-4">
                    <!-- Badge du plan -->
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-text-secondary">Plan actuel</p>
                            <p class="text-2xl font-bold text-text-primary mt-1">
                                <?php if($stats['subscription_info']['plan'] === 'free'): ?>
                                    Gratuit
                                <?php else: ?>
                                    <?php echo e(number_format($stats['subscription_info']['amount'], 0, ',', ' ')); ?> €<span class="text-sm font-normal text-text-secondary">/mois</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <?php if($stats['subscription_info']['plan'] === 'free'): ?>
                            <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                Gratuit
                            </span>
                        <?php elseif($stats['subscription_info']['plan'] === 'essential'): ?>
                            <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-primary/15 text-primary">
                                Essential
                            </span>
                        <?php else: ?>
                            <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-accent/15 text-accent-dark">
                                Pro
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Utilisation des offres -->
                    <div>
                        <div class="flex justify-between text-sm mb-2">
                            <span class="text-text-secondary">Offres utilisées</span>
                            <span class="font-medium text-text-primary">
                                <?php echo e($stats['active_trips']); ?>/<?php echo e($stats['max_trips'] == 9999 ? '∞' : $stats['max_trips']); ?>

                            </span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-primary h-2 rounded-full transition-all duration-300" 
                                 style="width: <?php echo e($stats['max_trips'] == 9999 ? '30' : min(($stats['active_trips'] / $stats['max_trips']) * 100, 100)); ?>%">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Commission -->
                    <div class="flex items-center justify-between py-3 border-t border-border">
                        <span class="text-sm text-text-secondary">Commission</span>
                        <span class="text-sm font-medium text-text-primary"><?php echo e($stats['commission_rate']); ?>%</span>
                    </div>
                    
                    <?php if($stats['subscription_info']['next_billing_date']): ?>
                        <div class="flex items-center justify-between py-3 border-t border-border">
                            <span class="text-sm text-text-secondary">Prochain paiement</span>
                            <span class="text-sm font-medium text-text-primary">
                                <?php echo e(\Carbon\Carbon::parse($stats['subscription_info']['next_billing_date'])->format('d/m/Y')); ?>

                            </span>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($vendor->subscription_plan !== 'pro'): ?>
                        <a href="<?php echo e(route('vendor.subscription.upgrade')); ?>" 
                           class="mt-4 w-full px-4 py-2 bg-primary hover:bg-primary-dark text-white font-medium rounded-lg transition-colors text-center flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 10l7-7m0 0l7 7m-7-7v18" />
                            </svg>
                            Upgrader mon plan
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Activité récente et Completion du profil -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Activité récente -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden card">
            <div class="p-6 border-b border-border">
                <h3 class="text-lg font-semibold text-text-primary">Activité récente</h3>
                <p class="text-sm text-text-secondary mt-1">Vos dernières actions et notifications</p>
            </div>
            <div class="divide-y divide-border">
                <?php $__empty_1 = true; $__currentLoopData = $recentActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-6 flex items-start hover:bg-bg-alt/30 transition-colors">
                        <div class="flex-shrink-0">
                            <div class="h-10 w-10 rounded-full bg-<?php echo e($activity['color']); ?>/10 flex items-center justify-center text-<?php echo e($activity['color']); ?>">
                                <i class="<?php echo e($activity['icon']); ?>"></i>
                            </div>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-text-primary"><?php echo e($activity['title']); ?></p>
                            <p class="text-xs text-text-secondary mt-1"><?php echo e($activity['description']); ?></p>
                            <p class="text-xs text-primary mt-1"><?php echo e($activity['date']->diffForHumans()); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-6 text-center">
                        <p class="text-sm text-text-secondary">Aucune activité récente</p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="px-6 py-4 bg-bg-alt border-t border-border">
                <a href="<?php echo e(route('vendor.activity.index')); ?>" class="text-sm text-primary hover:text-primary-dark font-medium flex items-center justify-center">
                    Voir toute l'activité
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </a>
            </div>
        </div>
        
        <!-- Completion du profil -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden card">
            <div class="p-6 border-b border-border">
                <h3 class="text-lg font-semibold text-text-primary">Complétude du profil</h3>
                <p class="text-sm text-text-secondary mt-1"><?php echo e($stats['completion_percentage']); ?>% complété</p>
            </div>
            
            <div class="p-6">
                <div class="mb-6">
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        <div class="bg-primary h-2 rounded-full transition-all duration-500" 
                             style="width: <?php echo e($stats['completion_percentage']); ?>%">
                        </div>
                    </div>
                </div>
                
                <div class="space-y-3">
                    <label class="flex items-center">
                        <input type="checkbox" class="h-4 w-4 text-primary rounded border-gray-300" <?php echo e($vendor->email_verified_at ? 'checked' : ''); ?> disabled>
                        <span class="ml-3 text-sm <?php echo e($vendor->email_verified_at ? 'text-text-secondary line-through' : 'text-text-primary'); ?>">
                            Email vérifié
                        </span>
                    </label>
                    <label class="flex items-center">
                        <input type="checkbox" class="h-4 w-4 text-primary rounded border-gray-300" <?php echo e($vendor->logo ? 'checked' : ''); ?> disabled>
                        <span class="ml-3 text-sm <?php echo e($vendor->logo ? 'text-text-secondary line-through' : 'text-text-primary'); ?>">
                            Logo ajouté
                        </span>
                    </label>
                    <label class="flex items-center">
                        <input type="checkbox" class="h-4 w-4 text-primary rounded border-gray-300" <?php echo e($vendor->description ? 'checked' : ''); ?> disabled>
                        <span class="ml-3 text-sm <?php echo e($vendor->description ? 'text-text-secondary line-through' : 'text-text-primary'); ?>">
                            Description complète
                        </span>
                    </label>
                    <label class="flex items-center">
                        <input type="checkbox" class="h-4 w-4 text-primary rounded border-gray-300" <?php echo e($stats['total_trips'] > 0 ? 'checked' : ''); ?> disabled>
                        <span class="ml-3 text-sm <?php echo e($stats['total_trips'] > 0 ? 'text-text-secondary line-through' : 'text-text-primary'); ?>">
                            Première offre créée
                        </span>
                    </label>
                </div>
                
                <?php if($stats['completion_percentage'] < 100): ?>
                    <a href="<?php echo e(route('vendor.settings.index')); ?>" 
                       class="mt-6 w-full px-4 py-2 bg-white border border-border text-text-primary hover:bg-bg-alt rounded-lg transition-colors text-center block font-medium">
                        Compléter mon profil
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    function dashboardData() {
        return {
            init() {
                this.initRevenueChart();
            },
            
            initRevenueChart() {
                const ctx = document.getElementById('revenueChart').getContext('2d');
                
                const gradient = ctx.createLinearGradient(0, 0, 0, 300);
                gradient.addColorStop(0, 'rgba(56, 178, 172, 0.3)');
                gradient.addColorStop(1, 'rgba(56, 178, 172, 0.0)');
                
                const chartData = <?php echo json_encode($chartData['monthly_stats'], 15, 512) ?>;
                
                const revenueChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: chartData.map(item => item.month_short),
                        datasets: [{
                            label: 'Revenus (€)',
                            data: chartData.map(item => item.revenue || Math.random() * 5000),
                            borderColor: '#38B2AC',
                            backgroundColor: gradient,
                            borderWidth: 2,
                            pointBackgroundColor: '#38B2AC',
                            pointBorderColor: '#ffffff',
                            pointBorderWidth: 2,
                            pointRadius: 4,
                            pointHoverRadius: 6,
                            tension: 0.3,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                backgroundColor: '#2D3748',
                                titleFont: {
                                    size: 13
                                },
                                bodyFont: {
                                    size: 12
                                },
                                displayColors: false,
                                callbacks: {
                                    label: function(context) {
                                        return new Intl.NumberFormat('fr-FR', { 
                                            style: 'currency', 
                                            currency: 'EUR' 
                                        }).format(context.parsed.y);
                                    }
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {
                                    drawBorder: false,
                                    color: '#E2E8F0'
                                },
                                ticks: {
                                    callback: function(value) {
                                        return value + ' €';
                                    },
                                    font: {
                                        size: 11
                                    },
                                    color: '#718096'
                                }
                            },
                            x: {
                                grid: {
                                    display: false,
                                    drawBorder: false
                                },
                                ticks: {
                                    font: {
                                        size: 11
                                    },
                                    color: '#718096'
                                }
                            }
                        },
                        interaction: {
                            intersect: false,
                            mode: 'index'
                        }
                    }
                });
            }
        }
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof Alpine !== 'undefined') {
            dashboardData().init();
        } else {
            dashboardData().init();
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jurojinn/test2.jewelme.fr/resources/views/vendor/dashboard/index.blade.php ENDPATH**/ ?>